
import React, { useState } from 'react';
import { 
  Box, Typography, Button, Paper, Radio, RadioGroup, FormControlLabel, 
  FormControl, Stepper, Step, StepLabel, CircularProgress, Fade, IconButton
} from '@mui/material';
import { ShieldAlert, CheckCircle, Home, Hammer, Flame, Zap, ArrowRight, ArrowLeft, X } from 'lucide-react';
import { db } from '../db';

// Helper for Persian Numbers
const toPersianDigits = (num: string | number) => {
  if (num === undefined || num === null) return '';
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, x => farsiDigits[parseInt(x)]);
};

const QUESTIONS = [
  {
    id: 'structure',
    label: 'نوع اسکلت و سازه ساختمان چیست؟',
    icon: <Home size={24} />,
    options: [
      { value: 'concrete', label: 'بتن آرمه یا اسکلت فلزی استاندارد', score: 25 },
      { value: 'brick_iron', label: 'دیوار باربر / آجر و آهن (نیمه اسکلت)', score: 10 },
      { value: 'old', label: 'بافت فرسوده / خشتی و گلی / بلوک سیمانی بدون شناژ', score: 0 },
    ]
  },
  {
    id: 'year',
    label: 'سال ساخت بنا تقریباً چه زمانی است؟',
    icon: <Hammer size={24} />,
    options: [
      { value: 'new', label: 'بعد از سال ۱۳۹۰ (رعایت مقررات ملی ساختمان)', score: 20 },
      { value: 'mid', label: 'بین سال‌های ۱۳۷۰ تا ۱۳۹۰', score: 10 },
      { value: 'old', label: 'قبل از سال ۱۳۷۰ (قدیمی ساز)', score: 0 },
    ]
  },
  {
    id: 'fire_safety',
    label: 'وضعیت تجهیزات اعلام و اطفاء حریق؟',
    icon: <Flame size={24} />,
    options: [
      { value: 'full', label: 'سیستم اعلام و اطفاء حریق اتوماتیک (اسپرینکلر)', score: 15 },
      { value: 'extinguisher', label: 'فقط کپسول آتش‌نشانی در طبقات', score: 8 },
      { value: 'none', label: 'فاقد هرگونه تجهیزات', score: 0 },
    ]
  },
  {
    id: 'wiring',
    label: 'وضعیت سیم‌کشی برق و تاسیسات؟',
    icon: <Zap size={24} />,
    options: [
      { value: 'standard', label: 'استاندارد / بازسازی شده کامل', score: 15 },
      { value: 'old', label: 'قدیمی و فرسوده', score: 5 },
      { value: 'exposed', label: 'روکار و غیرایمن (سیم‌های آویزان)', score: 0 },
    ]
  },
  {
    id: 'gas',
    label: 'وضعیت لوله‌کشی گاز؟',
    icon: <Flame size={24} className="text-blue-500" />,
    options: [
      { value: 'standard', label: 'توکار و تایید شده نظام مهندسی', score: 15 },
      { value: 'exposed', label: 'روکار / دارای زنگ زدگی یا نشتی جزئی', score: 5 },
    ]
  },
  {
    id: 'access',
    label: 'وضعیت دسترسی کوچه برای خودروهای امدادی؟',
    icon: <ShieldAlert size={24} />,
    options: [
      { value: 'wide', label: 'عریض (بیش از ۶ متر - ورود آسان ماشین آتش‌نشانی)', score: 10 },
      { value: 'medium', label: 'متوسط (۴ تا ۶ متر)', score: 5 },
      { value: 'narrow', label: 'باریک (کمتر از ۴ متر - عدم دسترسی ماشین سنگین)', score: 0 },
    ]
  }
];

interface RiskAssessmentProps {
    onClose?: () => void;
    onUpdate?: () => void;
}

const RiskAssessment: React.FC<RiskAssessmentProps> = ({ onClose, onUpdate }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [showResult, setShowResult] = useState(false);

  const handleSelect = (score: number) => {
    setAnswers({ ...answers, [QUESTIONS[activeStep].id]: score });
  };

  const calculateTotal = () => {
    return (Object.values(answers) as number[]).reduce((a, b) => a + b, 0);
  };

  const handleNext = () => {
    if (activeStep < QUESTIONS.length - 1) {
      setActiveStep(activeStep + 1);
    } else {
      setShowResult(true);
      // Save result
      const total = calculateTotal();
      db.saveRiskAssessment(total);
      if (onUpdate) onUpdate();
    }
  };

  const handleBack = () => {
    if (activeStep > 0) {
      setActiveStep(activeStep - 1);
    }
  };

  const getRiskLevel = (score: number) => {
    if (score >= 80) return { label: 'ایمن (کم‌خطر)', color: '#22c55e', desc: 'ساختمان شما وضعیت ایمنی مطلوبی دارد. نگهداری دوره‌ای را فراموش نکنید.' };
    if (score >= 50) return { label: 'ریسک متوسط', color: '#eab308', desc: 'ساختمان در برابر حوادث مقاومت نسبی دارد، اما نیاز به اصلاحات و تقویت نقاط ضعف است.' };
    return { label: 'پرخطر (نیازمند اقدام فوری)', color: '#ef4444', desc: 'ساختمان در برابر زلزله و آتش‌سوزی بسیار آسیب‌پذیر است. لطفاً هرچه سریع‌تر با کارشناسان ایمنی مشورت کنید.' };
  };

  if (showResult) {
    const total = calculateTotal();
    const result = getRiskLevel(total);

    return (
      <Fade in={true}>
        <div>
          <Box textAlign="center" p={3} dir="rtl">
              <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                  <Typography variant="h6" fontWeight="bold" fontFamily="Vazirmatn">
                      نتیجه ارزیابی ایمنی
                  </Typography>
                  {onClose && (
                      <IconButton onClick={onClose} size="small">
                          <X />
                      </IconButton>
                  )}
              </Box>
              
              <Box position="relative" display="inline-flex" mb={3} mt={2}>
              <CircularProgress 
                  variant="determinate" 
                  value={100} 
                  size={140} 
                  thickness={4} 
                  sx={{ color: '#e2e8f0', position: 'absolute' }} 
              />
              <CircularProgress 
                  variant="determinate" 
                  value={total} 
                  size={140} 
                  thickness={4} 
                  sx={{ 
                      color: result.color,
                      strokeLinecap: 'round'
                  }} 
              />
              <Box
                  sx={{
                  top: 0,
                  left: 0,
                  bottom: 0,
                  right: 0,
                  position: 'absolute',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexDirection: 'column'
                  }}
              >
                  <Typography variant="h3" component="div" color="text.primary" fontFamily="Vazirmatn" fontWeight="bold">
                  {toPersianDigits(total)}
                  </Typography>
                  <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn">
                      از ۱۰۰
                  </Typography>
              </Box>
              </Box>
              
              <Paper elevation={0} sx={{ bgcolor: `${result.color}15`, p: 2, borderRadius: 2, border: `1px solid ${result.color}40`, mb: 3 }}>
                  <Typography variant="h5" fontWeight="bold" fontFamily="Vazirmatn" gutterBottom sx={{ color: result.color }}>
                  {result.label}
                  </Typography>
                  <Typography variant="body2" fontFamily="Vazirmatn" color="text.secondary">
                  {result.desc}
                  </Typography>
              </Paper>

              <Button 
                  variant="outlined" 
                  fullWidth 
                  onClick={() => { setShowResult(false); setActiveStep(0); setAnswers({}); }}
                  sx={{ fontFamily: 'Vazirmatn' }}
              >
                  شروع مجدد ارزیابی
              </Button>
          </Box>
        </div>
      </Fade>
    );
  }

  const currentQ = QUESTIONS[activeStep];

  return (
    <Box sx={{ direction: 'rtl', p: 1 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6" fontWeight="bold" fontFamily="Vazirmatn">
            ارزیابی ریسک و ایمنی ساختمان
            </Typography>
            {onClose && (
                <IconButton onClick={onClose} size="small">
                    <X />
                </IconButton>
            )}
      </Box>
      
      <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4, direction: 'ltr' }}>
        {QUESTIONS.map((q) => (
          <Step key={q.id}>
            <StepLabel></StepLabel>
          </Step>
        ))}
      </Stepper>

      <Box key={currentQ.id}>
        <Fade in={true} appear={true}>
          <div>
            <Paper elevation={0} variant="outlined" sx={{ p: 3, borderRadius: 2, mb: 3, minHeight: 280 }}>
                <Box display="flex" alignItems="center" gap={1.5} mb={3} color="primary.main">
                    {currentQ.icon}
                    <Typography variant="subtitle1" fontWeight="bold" fontFamily="Vazirmatn">
                        {currentQ.label}
                    </Typography>
                </Box>
                
                <FormControl component="fieldset" sx={{ width: '100%' }}>
                    <RadioGroup
                        value={answers[currentQ.id] ?? ''}
                        onChange={(e) => handleSelect(Number(e.target.value))}
                    >
                        {currentQ.options.map((opt) => (
                            <FormControlLabel 
                                key={opt.value} 
                                value={opt.score} 
                                control={<Radio />} 
                                label={
                                    <Box sx={{ py: 0.5 }}>
                                        <Typography fontFamily="Vazirmatn" variant="body2">{opt.label}</Typography>
                                    </Box>
                                } 
                                sx={{ 
                                    border: '1px solid #f1f5f9', 
                                    borderRadius: 2, 
                                    m: 0, 
                                    mb: 1.5,
                                    px: 1,
                                    bgcolor: answers[currentQ.id] === opt.score ? '#eff6ff' : 'transparent',
                                    borderColor: answers[currentQ.id] === opt.score ? '#3b82f6' : '#f1f5f9',
                                    width: '100%'
                                }}
                            />
                        ))}
                    </RadioGroup>
                </FormControl>
            </Paper>
          </div>
        </Fade>
      </Box>

      <Box display="flex" gap={2}>
          <Button
            variant="outlined"
            onClick={handleBack}
            disabled={activeStep === 0}
            startIcon={<ArrowRight size={18} />}
            sx={{ fontFamily: 'Vazirmatn', minWidth: 100 }}
          >
              قبلی
          </Button>
          <Button 
            variant="contained" 
            fullWidth 
            size="large"
            onClick={handleNext}
            disabled={answers[currentQ.id] === undefined}
            endIcon={activeStep === QUESTIONS.length - 1 ? <CheckCircle size={18} /> : <ArrowLeft size={18} />}
            sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}
          >
            {activeStep === QUESTIONS.length - 1 ? 'مشاهده نتیجه نهایی' : 'سوال بعدی'}
          </Button>
      </Box>
    </Box>
  );
};

export default RiskAssessment;
