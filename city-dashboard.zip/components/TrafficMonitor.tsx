
import React, { useState, useEffect } from 'react';
import { 
  Box, Paper, Typography, Grid, LinearProgress, Button, Slider, 
  Card, CardContent, Chip, Alert, AlertTitle, Divider, List, ListItem, ListItemIcon, ListItemText
} from '@mui/material';
import { MapContainer, TileLayer, Circle, Popup, useMap } from 'react-leaflet';
import { Users, AlertTriangle, Navigation, RefreshCw, Car } from 'lucide-react';
import { db } from '../db';

// Helper for Persian Numbers
const toPersianDigits = (num: string | number) => {
  if (num === undefined || num === null) return '';
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, x => farsiDigits[parseInt(x)]);
};

const MapController = ({ center }: { center: [number, number] }) => {
  const map = useMap();
  useEffect(() => {
    map.flyTo(center, 14, { duration: 1.5 });
  }, [center, map]);
  return null;
};

const TrafficMonitor = () => {
  const [zones, setZones] = useState<any[]>([]);
  const [selectedZone, setSelectedZone] = useState<any>(null);
  const [simulatedDensity, setSimulatedDensity] = useState<number>(0);

  const loadData = () => {
      const data = db.getTrafficZones();
      setZones(data);
      if (selectedZone) {
          // Update selected zone data
          const updated = data.find((z: any) => z.id === selectedZone.id);
          if (updated) setSelectedZone(updated);
      }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleZoneClick = (zone: any) => {
      setSelectedZone(zone);
      setSimulatedDensity(zone.density);
  };

  const handleUpdateDensity = () => {
      if (!selectedZone) return;
      
      let newStatus = 'normal';
      if (simulatedDensity > 50) newStatus = 'heavy';
      if (simulatedDensity > 80) newStatus = 'critical';

      db.updateTrafficZone(selectedZone.id, {
          density: simulatedDensity,
          status: newStatus,
          currentCount: Math.round((simulatedDensity / 100) * selectedZone.capacity)
      });
      loadData();
  };

  const getStatusColor = (status: string) => {
      switch(status) {
          case 'normal': return '#22c55e'; // Green
          case 'heavy': return '#f97316'; // Orange
          case 'critical': return '#ef4444'; // Red
          default: return '#3b82f6';
      }
  };

  const getStatusLabel = (status: string) => {
      switch(status) {
          case 'normal': return 'روان / عادی';
          case 'heavy': return 'سنگین / متراکم';
          case 'critical': return 'بحرانی / ازدحام';
          default: return status;
      }
  };

  const center: [number, number] = selectedZone 
      ? [selectedZone.lat, selectedZone.lng] 
      : [34.6416, 50.8746]; // Default to Qom center approx

  return (
    <Box>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
            <Box>
                <Typography variant="h5" fontWeight="bold" fontFamily="Vazirmatn" color="text.primary">
                    <Car style={{ verticalAlign: 'middle', marginLeft: 8 }} />
                    مدیریت ترافیک و تراکم جمعیت
                </Typography>
                <Typography variant="body2" color="text.secondary" fontFamily="Vazirmatn" mt={1}>
                    پایش لحظه‌ای حرم مطهر و مسجد جمکران
                </Typography>
            </Box>
            <Button variant="outlined" startIcon={<RefreshCw />} onClick={loadData} sx={{ fontFamily: 'Vazirmatn' }}>
                بروزرسانی
            </Button>
        </Box>

        <Grid container spacing={3}>
            {/* Left Panel: List & Details */}
            <Grid size={{ xs: 12, md: 4 }}>
                <Box display="flex" flexDirection="column" gap={3}>
                    {/* Zone List */}
                    <Paper sx={{ p: 2, borderRadius: 2 }}>
                        <Typography variant="subtitle1" fontWeight="bold" fontFamily="Vazirmatn" mb={2}>مناطق تحت پوشش</Typography>
                        {zones.map(zone => (
                            <Card 
                                key={zone.id} 
                                elevation={selectedZone?.id === zone.id ? 3 : 1}
                                sx={{ 
                                    mb: 2, 
                                    cursor: 'pointer',
                                    border: selectedZone?.id === zone.id ? `2px solid ${getStatusColor(zone.status)}` : '1px solid transparent',
                                    bgcolor: selectedZone?.id === zone.id ? '#f8fafc' : 'white'
                                }}
                                onClick={() => handleZoneClick(zone)}
                            >
                                <CardContent sx={{ pb: '16px !important' }}>
                                    <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                                        <Typography variant="subtitle2" fontWeight="bold" fontFamily="Vazirmatn">{zone.name}</Typography>
                                        <Chip 
                                            label={getStatusLabel(zone.status)} 
                                            size="small"
                                            sx={{ 
                                                bgcolor: getStatusColor(zone.status), 
                                                color: 'white',
                                                fontFamily: 'Vazirmatn',
                                                height: 24
                                            }}
                                        />
                                    </Box>
                                    <Box display="flex" alignItems="center" gap={1} mb={1}>
                                        <Users size={16} className="text-gray-500" />
                                        <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn">
                                            جمعیت فعلی: {toPersianDigits(zone.currentCount.toLocaleString())} نفر
                                        </Typography>
                                    </Box>
                                    <LinearProgress 
                                        variant="determinate" 
                                        value={zone.density} 
                                        sx={{ 
                                            height: 6, 
                                            borderRadius: 3,
                                            bgcolor: '#e2e8f0',
                                            '& .MuiLinearProgress-bar': { bgcolor: getStatusColor(zone.status) }
                                        }} 
                                    />
                                </CardContent>
                            </Card>
                        ))}
                    </Paper>

                    {/* Controls & Alerts */}
                    {selectedZone && (
                        <Paper sx={{ p: 2, borderRadius: 2 }}>
                            <Typography variant="subtitle1" fontWeight="bold" fontFamily="Vazirmatn" mb={2} color="primary">
                                مدیریت تراکم: {selectedZone.name}
                            </Typography>
                            
                            {selectedZone.status === 'critical' && (
                                <Alert severity="error" icon={<AlertTriangle />} sx={{ mb: 2, fontFamily: 'Vazirmatn' }}>
                                    <AlertTitle sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>هشدار ازدحام جمعیت</AlertTitle>
                                    تراکم در این منطقه به سطح بحرانی رسیده است. لطفا مسیرهای جایگزین را فعال کنید.
                                </Alert>
                            )}

                            <Typography gutterBottom fontFamily="Vazirmatn" variant="body2">
                                شبیه‌سازی تراکم جمعیت ({toPersianDigits(simulatedDensity)}٪)
                            </Typography>
                            <Box display="flex" alignItems="center" gap={2}>
                                <Slider
                                    value={simulatedDensity}
                                    onChange={(e, v) => setSimulatedDensity(v as number)}
                                    aria-labelledby="density-slider"
                                    valueLabelDisplay="auto"
                                    sx={{ color: getStatusColor(selectedZone.status === 'critical' ? 'critical' : (simulatedDensity > 50 ? 'heavy' : 'normal')) }}
                                />
                                <Button size="small" variant="contained" onClick={handleUpdateDensity} sx={{ fontFamily: 'Vazirmatn', minWidth: 80 }}>
                                    اعمال
                                </Button>
                            </Box>

                            <Divider sx={{ my: 2 }} />

                            <Typography variant="subtitle2" fontWeight="bold" fontFamily="Vazirmatn" mb={1} display="flex" alignItems="center" gap={1}>
                                <Navigation size={16} /> مسیرهای جایگزین پیشنهادی
                            </Typography>
                            <List dense>
                                {selectedZone.altRoutes.map((route: string, idx: number) => (
                                    <ListItem key={idx}>
                                        <ListItemIcon sx={{ minWidth: 30 }}><div style={{ width: 6, height: 6, borderRadius: '50%', backgroundColor: '#3b82f6' }} /></ListItemIcon>
                                        <ListItemText 
                                            primary={<Typography variant="body2" fontFamily="Vazirmatn">{route}</Typography>} 
                                        />
                                    </ListItem>
                                ))}
                            </List>

                        </Paper>
                    )}
                </Box>
            </Grid>

            {/* Right Panel: Map */}
            <Grid size={{ xs: 12, md: 8 }}>
                <Paper sx={{ height: { xs: 400, md: 600 }, width: '100%', borderRadius: 2, overflow: 'hidden', border: '1px solid #e2e8f0' }}>
                    <MapContainer 
                        center={center} 
                        zoom={14} 
                        style={{ height: '100%', width: '100%' }}
                    >
                        <TileLayer
                            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        />
                        <MapController center={center} />
                        
                        {zones.map((zone) => (
                            <Circle 
                                key={zone.id}
                                center={[zone.lat, zone.lng]}
                                radius={zone.radius}
                                pathOptions={{ 
                                    color: getStatusColor(zone.status), 
                                    fillColor: getStatusColor(zone.status), 
                                    fillOpacity: 0.3, 
                                    weight: 2
                                }}
                                eventHandlers={{
                                    click: () => handleZoneClick(zone)
                                }}
                            >
                                <Popup>
                                    <div style={{ fontFamily: 'Vazirmatn', textAlign: 'right', direction: 'rtl' }}>
                                        <strong>{zone.name}</strong><br/>
                                        وضعیت: {getStatusLabel(zone.status)}<br/>
                                        تراکم: {toPersianDigits(zone.density)}٪<br/>
                                        جمعیت: {toPersianDigits(zone.currentCount)}
                                    </div>
                                </Popup>
                            </Circle>
                        ))}
                    </MapContainer>
                </Paper>
            </Grid>
        </Grid>
    </Box>
  );
};

export default TrafficMonitor;
