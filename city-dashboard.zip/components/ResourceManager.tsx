
import React, { useState, useEffect } from 'react';
import { 
  Box, Paper, Typography, Grid, Chip, Button, Table, TableBody, TableCell, 
  TableContainer, TableHead, TableRow, IconButton, Card, CardContent,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField,
  FormControl, InputLabel, Select, MenuItem, InputAdornment, List, ListItem, ListItemText, ListItemIcon, Divider
} from '@mui/material';
import { Truck, Activity, Wrench, Ambulance, Zap, RefreshCw, Plus, Edit, Trash2, X, Search, Shield, Plane, History, FileText } from 'lucide-react';
import { db } from '../db';

// Helper for Persian Numbers
const toPersianDigits = (num: string | number) => {
  if (num === undefined || num === null) return '';
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, x => farsiDigits[parseInt(x)]);
};

const ResourceManager = () => {
  const [resources, setResources] = useState<any[]>([]);
  const [incidents, setIncidents] = useState<any[]>([]);
  
  // Dialog States
  const [openDialog, setOpenDialog] = useState(false);
  const [maintenanceDialogOpen, setMaintenanceDialogOpen] = useState(false);
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);
  
  const [isEditing, setIsEditing] = useState(false);
  const [currentId, setCurrentId] = useState<number | null>(null);
  const [formData, setFormData] = useState({ name: '', type: '' });
  
  // Maintenance & History Data
  const [maintenanceReason, setMaintenanceReason] = useState('');
  const [targetResource, setTargetResource] = useState<any>(null);
  const [resourceHistory, setResourceHistory] = useState<any[]>([]);

  // Search and Filter State
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');

  const loadData = () => {
      setResources(db.getResources());
      setIncidents(db.getIncidents());
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 5000);
    return () => clearInterval(interval);
  }, []);

  // Action Handlers
  const handleMaintenance = (res: any) => {
      setTargetResource(res);
      setMaintenanceReason('');
      setMaintenanceDialogOpen(true);
  };

  const submitMaintenance = () => {
      if (targetResource) {
          db.updateResourceStatus(targetResource.id, 'Maintenance', null, maintenanceReason || 'اعزام به تعمیرگاه');
          setMaintenanceDialogOpen(false);
          loadData();
      }
  };

  const handleRelease = (res: any) => {
      db.updateResourceStatus(res.id, 'Available', null);
      loadData();
  };
  
  const handleFinishMission = (res: any) => {
      db.updateResourceStatus(res.id, 'Available', null);
      loadData();
  };

  const handleViewHistory = (res: any) => {
      setTargetResource(res);
      const logs = db.getResourceLogs(res.id);
      setResourceHistory(logs);
      setHistoryDialogOpen(true);
  };

  const handleOpenAdd = () => {
    setFormData({ name: '', type: '' });
    setIsEditing(false);
    setOpenDialog(true);
  };

  const handleOpenEdit = (res: any) => {
    setFormData({ name: res.name, type: res.type });
    setCurrentId(res.id);
    setIsEditing(true);
    setOpenDialog(true);
  };

  const handleDelete = (id: number) => {
    if (window.confirm('آیا از حذف این منبع اطمینان دارید؟')) {
        db.deleteResource(id);
        loadData();
    }
  };

  const handleSave = () => {
    if (!formData.name || !formData.type) return;
    
    const payload = {
        ...(isEditing ? { id: currentId } : {}),
        name: formData.name,
        type: formData.type
    };
    
    db.saveResource(payload);
    setOpenDialog(false);
    loadData();
  };

  const getTypeIcon = (type: string) => {
      if (type.includes('آتش')) return <Truck className="text-red-500" />;
      if (type.includes('آمبولانس')) return <Ambulance className="text-blue-500" />;
      if (type.includes('تجهیزات') || type.includes('ژنراتور')) return <Zap className="text-yellow-600" />;
      if (type.includes('پلیس')) return <Shield className="text-green-600" />;
      if (type.includes('هوایی')) return <Plane className="text-sky-500" />;
      return <Wrench className="text-gray-500" />;
  };

  const getStatusColor = (status: string) => {
      switch(status) {
          case 'Available': return 'success';
          case 'Dispatched': return 'warning';
          case 'Maintenance': return 'error';
          default: return 'default';
      }
  };

  const getStatusLabel = (status: string) => {
      switch(status) {
          case 'Available': return 'آماده‌باش';
          case 'Dispatched': return 'در ماموریت';
          case 'Maintenance': return 'در تعمیرگاه';
          default: return status;
      }
  };
  
  const getIncidentTitle = (id: number) => {
      const inc = incidents.find(i => i.id === id);
      return inc ? inc.title : `حادثه ${toPersianDigits(id)}`;
  };

  const filteredResources = resources.filter(res => {
      const matchesSearch = res.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = filterType === 'all' || res.type === filterType;
      return matchesSearch && matchesType;
  });

  const uniqueTypes = Array.from(new Set(resources.map(r => r.type)));

  const stats = {
      total: resources.length,
      available: resources.filter(r => r.status === 'Available').length,
      dispatched: resources.filter(r => r.status === 'Dispatched').length,
      maintenance: resources.filter(r => r.status === 'Maintenance').length,
  };

  return (
    <Box>
         {/* Stats Cards */}
         <Grid container spacing={3} mb={4}>
            <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                <Card>
                    <CardContent sx={{ textAlign: 'center' }}>
                        <Typography color="text.secondary" fontFamily="Vazirmatn">کل ناوگان</Typography>
                        <Typography variant="h4" fontWeight="bold" fontFamily="Vazirmatn">{toPersianDigits(stats.total)}</Typography>
                    </CardContent>
                </Card>
            </Grid>
            <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                <Card sx={{ borderBottom: '4px solid #22c55e' }}>
                    <CardContent sx={{ textAlign: 'center' }}>
                        <Typography color="text.secondary" fontFamily="Vazirmatn">آماده به کار</Typography>
                        <Typography variant="h4" fontWeight="bold" fontFamily="Vazirmatn" color="success.main">{toPersianDigits(stats.available)}</Typography>
                    </CardContent>
                </Card>
            </Grid>
            <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                <Card sx={{ borderBottom: '4px solid #f97316' }}>
                    <CardContent sx={{ textAlign: 'center' }}>
                        <Typography color="text.secondary" fontFamily="Vazirmatn">در حال ماموریت</Typography>
                        <Typography variant="h4" fontWeight="bold" fontFamily="Vazirmatn" color="warning.main">{toPersianDigits(stats.dispatched)}</Typography>
                    </CardContent>
                </Card>
            </Grid>
            <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                <Card sx={{ borderBottom: '4px solid #ef4444' }}>
                    <CardContent sx={{ textAlign: 'center' }}>
                        <Typography color="text.secondary" fontFamily="Vazirmatn">خارج از سرویس</Typography>
                        <Typography variant="h4" fontWeight="bold" fontFamily="Vazirmatn" color="error.main">{toPersianDigits(stats.maintenance)}</Typography>
                    </CardContent>
                </Card>
            </Grid>
         </Grid>

         {/* Resources Table */}
         <Paper elevation={2} sx={{ overflow: 'hidden', borderRadius: 2 }}>
             <Box p={2} display="flex" flexDirection={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems="center" bgcolor="#f8fafc" borderBottom={1} borderColor="divider" gap={2}>
                 <Typography variant="h6" fontFamily="Vazirmatn" fontWeight="bold">لیست منابع عملیاتی</Typography>
                 
                 {/* Filters */}
                 <Box display="flex" gap={2} flex={1} maxWidth={600}>
                     <TextField 
                        size="small"
                        placeholder="جستجوی نام منبع..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        fullWidth
                        InputProps={{
                            startAdornment: <InputAdornment position="start"><Search size={16} /></InputAdornment>
                        }}
                        sx={{ bgcolor: 'white', '& .MuiInputBase-root': { fontFamily: 'Vazirmatn' } }}
                     />
                     <FormControl size="small" sx={{ minWidth: 150, bgcolor: 'white' }}>
                        <Select
                            value={filterType}
                            onChange={(e) => setFilterType(e.target.value)}
                            displayEmpty
                            sx={{ fontFamily: 'Vazirmatn' }}
                        >
                            <MenuItem value="all" sx={{ fontFamily: 'Vazirmatn' }}>همه انواع</MenuItem>
                            {uniqueTypes.map(type => (
                                <MenuItem key={type} value={type} sx={{ fontFamily: 'Vazirmatn' }}>{type}</MenuItem>
                            ))}
                        </Select>
                     </FormControl>
                 </Box>

                 <Box display="flex" gap={2}>
                    <Button variant="contained" startIcon={<Plus size={16} />} onClick={handleOpenAdd} sx={{ fontFamily: 'Vazirmatn' }}>
                        افزودن منبع
                    </Button>
                    <IconButton onClick={loadData} title="بروزرسانی">
                        <RefreshCw size={18} />
                    </IconButton>
                 </Box>
             </Box>
             <TableContainer sx={{ maxHeight: 600 }}>
                 <Table dir="rtl" stickyHeader>
                     <TableHead>
                         <TableRow>
                             <TableCell sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>شناسه</TableCell>
                             <TableCell sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>نام منبع</TableCell>
                             <TableCell sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>نوع</TableCell>
                             <TableCell sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>وضعیت فعلی</TableCell>
                             <TableCell sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>ماموریت فعال</TableCell>
                             <TableCell sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>عملیات</TableCell>
                         </TableRow>
                     </TableHead>
                     <TableBody>
                         {filteredResources.map((res) => (
                             <TableRow key={res.id} hover>
                                 <TableCell sx={{ fontFamily: 'Vazirmatn' }}>{toPersianDigits(res.id)}</TableCell>
                                 <TableCell sx={{ fontFamily: 'Vazirmatn' }}>{res.name}</TableCell>
                                 <TableCell sx={{ fontFamily: 'Vazirmatn' }}>
                                     <Box display="flex" alignItems="center" gap={1}>
                                         {getTypeIcon(res.type)}
                                         {res.type}
                                     </Box>
                                 </TableCell>
                                 <TableCell>
                                     <Chip 
                                        label={getStatusLabel(res.status)} 
                                        color={getStatusColor(res.status) as any}
                                        size="small"
                                        sx={{ fontFamily: 'Vazirmatn', minWidth: 80 }}
                                     />
                                 </TableCell>
                                 <TableCell sx={{ fontFamily: 'Vazirmatn' }}>
                                     {res.incidentId ? (
                                         <Chip 
                                            label={getIncidentTitle(res.incidentId)}
                                            color="warning"
                                            variant="outlined"
                                            size="small"
                                            onClick={() => alert(`جزئیات حادثه ${toPersianDigits(res.incidentId)}`)}
                                            sx={{ fontFamily: 'Vazirmatn', cursor: 'pointer', maxWidth: 200 }}
                                         />
                                     ) : (
                                         <Typography variant="caption" color="text.disabled">بدون ماموریت</Typography>
                                     )}
                                 </TableCell>
                                 <TableCell>
                                     <Box display="flex" gap={1} alignItems="center">
                                         
                                         {/* Dynamic Action Buttons */}
                                         {res.status === 'Available' && (
                                            <Button 
                                                size="small" 
                                                variant="outlined"
                                                color="error"
                                                onClick={() => handleMaintenance(res)}
                                                sx={{ fontFamily: 'Vazirmatn', fontSize: '0.7rem', minWidth: 80 }}
                                            >
                                                تعمیر
                                            </Button>
                                         )}
                                         {res.status === 'Maintenance' && (
                                            <Button 
                                                size="small" 
                                                variant="outlined"
                                                color="success"
                                                onClick={() => handleRelease(res)}
                                                sx={{ fontFamily: 'Vazirmatn', fontSize: '0.7rem', minWidth: 80 }}
                                            >
                                                بازگشت
                                            </Button>
                                         )}
                                         {res.status === 'Dispatched' && (
                                             <Button 
                                                size="small"
                                                variant="contained"
                                                color="warning"
                                                onClick={() => handleFinishMission(res)}
                                                sx={{ fontFamily: 'Vazirmatn', fontSize: '0.7rem', minWidth: 80 }}
                                             >
                                                 پایان ماموریت
                                             </Button>
                                         )}

                                         <IconButton size="small" color="primary" onClick={() => handleViewHistory(res)} title="تاریخچه و گزارشات">
                                            <History size={16} />
                                         </IconButton>
                                         <IconButton size="small" color="default" onClick={() => handleOpenEdit(res)}>
                                            <Edit size={16} />
                                         </IconButton>
                                         <IconButton size="small" color="default" onClick={() => handleDelete(res.id)}>
                                            <Trash2 size={16} />
                                         </IconButton>
                                     </Box>
                                 </TableCell>
                             </TableRow>
                         ))}
                         {filteredResources.length === 0 && (
                             <TableRow>
                                 <TableCell colSpan={6} align="center" sx={{ py: 3, fontFamily: 'Vazirmatn', color: 'text.secondary' }}>
                                     منبعی یافت نشد.
                                 </TableCell>
                             </TableRow>
                         )}
                     </TableBody>
                 </Table>
             </TableContainer>
         </Paper>

         {/* Add/Edit Dialog */}
         <Dialog open={openDialog} onClose={() => setOpenDialog(false)} fullWidth maxWidth="sm" dir="rtl">
             <DialogTitle sx={{ fontFamily: 'Vazirmatn', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                 {isEditing ? 'ویرایش منبع' : 'افزودن منبع جدید'}
                 <IconButton onClick={() => setOpenDialog(false)} size="small"><X /></IconButton>
             </DialogTitle>
             <DialogContent>
                 <Box display="flex" flexDirection="column" gap={2} mt={1}>
                     <TextField
                        label="نام منبع"
                        fullWidth
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="مثال: آمبولانس کد ۴۴"
                        sx={{ '& .MuiInputBase-root': { fontFamily: 'Vazirmatn' }, '& .MuiInputLabel-root': { fontFamily: 'Vazirmatn' } }}
                     />
                     <FormControl fullWidth>
                        <InputLabel sx={{ fontFamily: 'Vazirmatn' }}>نوع منبع</InputLabel>
                        <Select
                            value={formData.type}
                            label="نوع منبع"
                            onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                            sx={{ fontFamily: 'Vazirmatn' }}
                        >
                            <MenuItem value="آمبولانس" sx={{ fontFamily: 'Vazirmatn' }}>آمبولانس</MenuItem>
                            <MenuItem value="آتش‌نشانی" sx={{ fontFamily: 'Vazirmatn' }}>آتش‌نشانی</MenuItem>
                            <MenuItem value="تیم امدادی" sx={{ fontFamily: 'Vazirmatn' }}>تیم امدادی</MenuItem>
                            <MenuItem value="تجهیزات" sx={{ fontFamily: 'Vazirmatn' }}>تجهیزات</MenuItem>
                            <MenuItem value="پلیس" sx={{ fontFamily: 'Vazirmatn' }}>پلیس</MenuItem>
                            <MenuItem value="ماشین‌آلات سنگین" sx={{ fontFamily: 'Vazirmatn' }}>ماشین‌آلات سنگین</MenuItem>
                            <MenuItem value="امداد هوایی" sx={{ fontFamily: 'Vazirmatn' }}>امداد هوایی</MenuItem>
                            <MenuItem value="سایر" sx={{ fontFamily: 'Vazirmatn' }}>سایر</MenuItem>
                        </Select>
                     </FormControl>
                 </Box>
             </DialogContent>
             <DialogActions sx={{ p: 2 }}>
                 <Button onClick={() => setOpenDialog(false)} sx={{ fontFamily: 'Vazirmatn' }}>انصراف</Button>
                 <Button onClick={handleSave} variant="contained" color="primary" sx={{ fontFamily: 'Vazirmatn' }}>
                     {isEditing ? 'ذخیره تغییرات' : 'افزودن'}
                 </Button>
             </DialogActions>
         </Dialog>

         {/* Maintenance Dialog */}
         <Dialog open={maintenanceDialogOpen} onClose={() => setMaintenanceDialogOpen(false)} fullWidth maxWidth="xs" dir="rtl">
             <DialogTitle sx={{ fontFamily: 'Vazirmatn' }}>ثبت گزارش خرابی / تعمیر</DialogTitle>
             <DialogContent>
                 <Typography variant="body2" color="text.secondary" fontFamily="Vazirmatn" mb={2}>
                     علت خارج کردن منبع <strong>{targetResource?.name}</strong> از سرویس را وارد کنید:
                 </Typography>
                 <TextField
                    label="علت / گزارش"
                    multiline
                    rows={3}
                    fullWidth
                    value={maintenanceReason}
                    onChange={(e) => setMaintenanceReason(e.target.value)}
                    placeholder="مثال: خرابی موتور، سرویس دوره‌ای..."
                    sx={{ '& .MuiInputBase-root': { fontFamily: 'Vazirmatn' }, '& .MuiInputLabel-root': { fontFamily: 'Vazirmatn' } }}
                 />
             </DialogContent>
             <DialogActions sx={{ p: 2 }}>
                 <Button onClick={() => setMaintenanceDialogOpen(false)} sx={{ fontFamily: 'Vazirmatn' }}>لغو</Button>
                 <Button onClick={submitMaintenance} variant="contained" color="error" sx={{ fontFamily: 'Vazirmatn' }}>
                     ثبت و تغییر وضعیت
                 </Button>
             </DialogActions>
         </Dialog>

         {/* History Dialog */}
         <Dialog open={historyDialogOpen} onClose={() => setHistoryDialogOpen(false)} fullWidth maxWidth="sm" dir="rtl">
             <DialogTitle sx={{ fontFamily: 'Vazirmatn', display: 'flex', alignItems: 'center', gap: 1 }}>
                 <History size={20} /> تاریخچه و گزارشات: {targetResource?.name}
             </DialogTitle>
             <DialogContent>
                 {resourceHistory.length === 0 ? (
                     <Typography color="text.secondary" align="center" py={4} fontFamily="Vazirmatn">هیچ سابقه‌ای موجود نیست.</Typography>
                 ) : (
                     <List>
                         {resourceHistory.map((log) => (
                             <React.Fragment key={log.id}>
                                 <ListItem alignItems="flex-start">
                                     <ListItemIcon sx={{ minWidth: 36 }}>
                                         <FileText size={18} className="text-gray-500" />
                                     </ListItemIcon>
                                     <ListItemText
                                        primary={
                                            <Box display="flex" justifyContent="space-between">
                                                <Typography variant="subtitle2" fontFamily="Vazirmatn" fontWeight="bold">{log.action}</Typography>
                                                <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn">
                                                    {new Date(log.timestamp).toLocaleDateString('fa-IR')}
                                                </Typography>
                                            </Box>
                                        }
                                        secondary={
                                            <React.Fragment>
                                                <Typography variant="body2" fontFamily="Vazirmatn" color="text.primary" mt={0.5}>
                                                    {log.description}
                                                </Typography>
                                                <Typography variant="caption" fontFamily="Vazirmatn" color="text.secondary" display="block">
                                                    کاربر: {log.user} | {new Date(log.timestamp).toLocaleTimeString('fa-IR')}
                                                </Typography>
                                            </React.Fragment>
                                        }
                                     />
                                 </ListItem>
                                 <Divider component="li" />
                             </React.Fragment>
                         ))}
                     </List>
                 )}
             </DialogContent>
             <DialogActions sx={{ p: 2 }}>
                 <Button onClick={() => setHistoryDialogOpen(false)} sx={{ fontFamily: 'Vazirmatn' }}>بستن</Button>
             </DialogActions>
         </Dialog>
    </Box>
  );
};

export default ResourceManager;
