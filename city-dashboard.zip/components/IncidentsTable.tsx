
import React, { useState, useEffect } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  IconButton,
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  Grid,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
  ListItemButton,
  InputAdornment,
  useTheme,
  useMediaQuery,
  Stack
} from '@mui/material';
import { Edit, Trash2, Plus, X, MapPin, History, Truck, PlusCircle, Check, Search, Filter } from 'lucide-react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import { db } from '../db';

// Fix Leaflet Icons
const createIcon = (color: string) => new L.Icon({
  iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});
const redIcon = createIcon('red');

// Helper for Persian Numbers
const toPersianDigits = (num: string | number) => {
  if (num === null || num === undefined) return '';
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, x => farsiDigits[parseInt(x)]);
};

interface IncidentData {
  id: number;
  title: string;
  type: string;
  reporter: string;
  status: 'جدید' | 'در حال بررسی' | 'حل شده';
  region: string;
  neighborhood: string;
  address: string;
  lat: number;
  lng: number;
}

// Map Click Handler Component
const LocationMarker = ({ setFormData }: { setFormData: React.Dispatch<React.SetStateAction<any>> }) => {
  useMapEvents({
    click(e) {
      setFormData((prev: any) => ({
        ...prev,
        lat: parseFloat(e.latlng.lat.toFixed(6)),
        lng: parseFloat(e.latlng.lng.toFixed(6))
      }));
    },
  });
  return null;
};

interface IncidentsTableProps {
  onDataChange?: () => void;
}

const IncidentsTable: React.FC<IncidentsTableProps> = ({ onDataChange }) => {
  const [incidents, setIncidents] = useState<IncidentData[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [tabIndex, setTabIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
  
  // Data for tabs
  const [logs, setLogs] = useState<any[]>([]);
  const [resources, setResources] = useState<any[]>([]);
  
  // Form State
  const [currentId, setCurrentId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    type: '',
    reporter: '',
    status: 'جدید',
    region: '',
    neighborhood: '',
    address: '',
    lat: 34.64,
    lng: 50.87
  });

  useEffect(() => {
    // Load data from DB on mount
    setIncidents(db.getIncidents());
  }, []);

  const refreshData = () => {
    setIncidents(db.getIncidents());
    if (onDataChange) onDataChange();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'جدید': return 'error';
      case 'در حال بررسی': return 'warning';
      case 'حل شده': return 'success';
      default: return 'default';
    }
  };

  // --- Handlers ---

  const handleOpenAdd = () => {
    setIsEditing(false);
    setTabIndex(0);
    setFormData({ 
      title: '', type: '', reporter: '', status: 'جدید',
      region: '', neighborhood: '', address: '', lat: 34.64, lng: 50.87
    });
    setOpenDialog(true);
  };

  const handleOpenEdit = (incident: IncidentData) => {
    setIsEditing(true);
    setTabIndex(0);
    setCurrentId(incident.id);
    setFormData({
      title: incident.title,
      type: incident.type,
      reporter: incident.reporter,
      status: incident.status,
      region: incident.region,
      neighborhood: incident.neighborhood,
      address: incident.address,
      lat: Number(incident.lat),
      lng: Number(incident.lng)
    });
    
    // Load logs and resources
    setLogs(db.getIncidentLogs(incident.id));
    setResources(db.getResources());
    
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleDelete = (id: number) => {
    if (window.confirm('آیا از حذف این گزارش اطمینان دارید؟')) {
      db.deleteIncident(id);
      refreshData();
    }
  };

  const handleSave = () => {
    if (!formData.title || !formData.type) {
      alert('لطفا فیلدهای ضروری (عنوان و نوع) را پر کنید');
      return;
    }

    const incidentToSave = {
      ...(isEditing ? { id: currentId } : {}),
      ...formData
    };

    db.saveIncident(incidentToSave);
    refreshData();
    handleCloseDialog();
  };

  const handleResourceAssign = (resourceId: number) => {
      if (!currentId) return;
      db.assignResource(resourceId, currentId);
      // Refresh local resource list
      setResources(db.getResources());
  };

  const handleResourceRelease = (resourceId: number) => {
      db.releaseResource(resourceId);
      setResources(db.getResources());
  };

  const filteredIncidents = incidents.filter(inc => 
    inc.title.includes(searchQuery) || 
    inc.type.includes(searchQuery) ||
    inc.region?.includes(searchQuery)
  );

  // --- Render Tabs ---

  const renderTimelineTab = () => (
      <Box mt={2}>
          {logs.length === 0 ? (
              <Typography color="text.secondary" fontFamily="Vazirmatn">هیچ تاریخچه‌ای ثبت نشده است.</Typography>
          ) : (
              <List>
                  {logs.map((log) => (
                      <React.Fragment key={log.id}>
                        <ListItem alignItems="flex-start">
                            <ListItemIcon sx={{ minWidth: 40 }}>
                                <History size={20} className="text-gray-500" />
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Box display="flex" justifyContent="space-between">
                                        <Typography variant="subtitle2" fontFamily="Vazirmatn" fontWeight="bold">{log.action}</Typography>
                                        <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn">
                                            {new Date(log.timestamp).toLocaleTimeString('fa-IR')}
                                        </Typography>
                                    </Box>
                                }
                                secondary={
                                    <Typography variant="body2" fontFamily="Vazirmatn" color="text.secondary" mt={0.5}>
                                        توسط: {log.user} - {new Date(log.timestamp).toLocaleDateString('fa-IR')}
                                    </Typography>
                                }
                            />
                        </ListItem>
                        <Divider component="li" />
                      </React.Fragment>
                  ))}
              </List>
          )}
      </Box>
  );

  const renderResourcesTab = () => {
      const assigned = resources.filter(r => r.incidentId === currentId);
      const available = resources.filter(r => r.status === 'Available');

      return (
          <Box mt={2}>
              <Typography variant="subtitle2" fontWeight="bold" fontFamily="Vazirmatn" gutterBottom color="primary">
                  منابع تخصیص یافته به این حادثه
              </Typography>
              {assigned.length === 0 ? (
                  <Typography variant="body2" color="text.secondary" fontFamily="Vazirmatn" mb={2}>موردی یافت نشد.</Typography>
              ) : (
                  <List dense sx={{ bgcolor: '#f0fdf4', borderRadius: 1, mb: 3 }}>
                      {assigned.map(res => (
                          <ListItem key={res.id}
                            secondaryAction={
                                <Button size="small" color="error" onClick={() => handleResourceRelease(res.id)} sx={{ fontFamily: 'Vazirmatn' }}>
                                    آزادسازی
                                </Button>
                            }
                          >
                              <ListItemIcon><Truck size={18} /></ListItemIcon>
                              <ListItemText 
                                  primary={<Typography fontFamily="Vazirmatn" variant="body2" fontWeight="bold">{res.name}</Typography>} 
                                  secondary={<Typography fontFamily="Vazirmatn" variant="caption">{res.type}</Typography>} 
                              />
                          </ListItem>
                      ))}
                  </List>
              )}

              <Typography variant="subtitle2" fontWeight="bold" fontFamily="Vazirmatn" gutterBottom mt={3} color="text.secondary">
                  تخصیص منبع جدید (موجود در انبار/ایستگاه)
              </Typography>
              <List dense>
                  {available.map(res => (
                      <ListItem key={res.id} divider disablePadding>
                           <ListItemButton onClick={() => handleResourceAssign(res.id)}>
                             <ListItemIcon><PlusCircle size={18} className="text-gray-400" /></ListItemIcon>
                             <ListItemText 
                                  primary={<Typography fontFamily="Vazirmatn" variant="body2">{res.name}</Typography>}
                                  secondary={<Typography fontFamily="Vazirmatn" variant="caption">{res.type}</Typography>}
                             />
                             <Button size="small" startIcon={<Plus size={14}/>} sx={{ fontFamily: 'Vazirmatn' }}>افزودن</Button>
                           </ListItemButton>
                      </ListItem>
                  ))}
                  {available.length === 0 && (
                      <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn">هیچ منبع آزادی موجود نیست.</Typography>
                  )}
              </List>
          </Box>
      );
  };

  return (
    <Box>
      {/* Enhanced Toolbar */}
      <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ xs: 'stretch', md: 'center' }} mb={3} spacing={2}>
        <Box>
            <Typography variant="h6" fontWeight="bold" fontFamily="Vazirmatn">
            مدیریت گزارش‌های بحران
            </Typography>
            <Typography variant="body2" color="text.secondary" fontFamily="Vazirmatn">
                لیست تمامی حوادث ثبت شده توسط شهروندان و سیستم
            </Typography>
        </Box>
        
        <Box display="flex" flexDirection={{ xs: 'column', sm: 'row' }} gap={2} alignItems={{ xs: 'stretch', sm: 'center' }}>
             <TextField
                size="small"
                placeholder="جستجو در حوادث..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                InputProps={{
                    startAdornment: <InputAdornment position="start"><Search size={16} /></InputAdornment>,
                    sx: { fontFamily: 'Vazirmatn', bgcolor: 'white' }
                }}
                fullWidth={fullScreen}
             />
             <Button 
                variant="contained" 
                color="primary" 
                size="medium"
                startIcon={<Plus size={20} />}
                onClick={handleOpenAdd}
                sx={{ 
                    fontFamily: 'Vazirmatn', 
                    fontWeight: 'bold', 
                    px: 3, 
                    whiteSpace: 'nowrap'
                }}
                fullWidth={fullScreen}
            >
                ثبت گزارش جدید
            </Button>
        </Box>
      </Stack>

      {/* Table */}
      <TableContainer component={Paper} elevation={2} sx={{ borderRadius: 2, overflowX: 'auto', direction: 'rtl', border: '1px solid #e2e8f0' }}>
        <Table sx={{ minWidth: 650 }} aria-label="incidents table">
          <TableHead sx={{ bgcolor: '#f8fafc' }}>
            <TableRow>
              <TableCell align="right" sx={{ fontWeight: 'bold', fontFamily: 'Vazirmatn, sans-serif' }}>شناسه</TableCell>
              <TableCell align="right" sx={{ fontWeight: 'bold', fontFamily: 'Vazirmatn, sans-serif' }}>عنوان حادثه</TableCell>
              <TableCell align="right" sx={{ fontWeight: 'bold', fontFamily: 'Vazirmatn, sans-serif' }}>منطقه / محله</TableCell>
              <TableCell align="right" sx={{ fontWeight: 'bold', fontFamily: 'Vazirmatn, sans-serif' }}>نوع</TableCell>
              <TableCell align="right" sx={{ fontWeight: 'bold', fontFamily: 'Vazirmatn, sans-serif' }}>وضعیت</TableCell>
              <TableCell align="right" sx={{ fontWeight: 'bold', fontFamily: 'Vazirmatn, sans-serif' }}>عملیات</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredIncidents.map((row) => (
              <TableRow
                key={row.id}
                sx={{ '&:last-child td, &:last-child th': { border: 0 }, '&:hover': { bgcolor: '#f1f5f9' } }}
              >
                <TableCell align="right" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>{toPersianDigits(row.id)}</TableCell>
                <TableCell align="right" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>
                  <Typography variant="body2" sx={{ fontFamily: 'Vazirmatn, sans-serif', fontWeight: 'bold' }}>{row.title}</Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>
                    {row.reporter && `توسط: ${row.reporter}`}
                  </Typography>
                </TableCell>
                <TableCell align="right" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>
                   {row.region && `منطقه ${toPersianDigits(row.region)}`}
                   {row.region && row.neighborhood && ' - '}
                   {row.neighborhood}
                </TableCell>
                <TableCell align="right" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>
                    <Chip label={row.type} size="small" variant="outlined" sx={{ fontFamily: 'Vazirmatn' }} />
                </TableCell>
                <TableCell align="right">
                  <Chip 
                    label={row.status} 
                    color={getStatusColor(row.status) as any} 
                    size="small" 
                    sx={{ fontFamily: 'Vazirmatn, sans-serif', fontWeight: 500 }}
                  />
                </TableCell>
                <TableCell align="right">
                  <Box display="flex" gap={1} justifyContent="flex-start">
                    <IconButton size="small" color="primary" onClick={() => handleOpenEdit(row)} title="ویرایش و جزئیات">
                      <Edit size={18} />
                    </IconButton>
                    <IconButton size="small" color="error" onClick={() => handleDelete(row.id)} title="حذف">
                      <Trash2 size={18} />
                    </IconButton>
                  </Box>
                </TableCell>
              </TableRow>
            ))}
            {filteredIncidents.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} align="center" sx={{ py: 6, fontFamily: 'Vazirmatn' }}>
                  <Box display="flex" flexDirection="column" alignItems="center" gap={1} color="text.secondary">
                    <Filter size={32} />
                    <Typography>گزارشی یافت نشد</Typography>
                  </Box>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Add/Edit Dialog */}
      <Dialog 
        open={openDialog} 
        onClose={handleCloseDialog} 
        fullWidth 
        maxWidth="md"
        fullScreen={fullScreen}
        dir="rtl"
      >
        <DialogTitle sx={{ fontFamily: 'Vazirmatn, sans-serif', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          {isEditing ? 'مدیریت و ویرایش گزارش' : 'ثبت گزارش جدید'}
          <IconButton onClick={handleCloseDialog} size="small">
            <X size={20} />
          </IconButton>
        </DialogTitle>
        <DialogContent sx={{ pt: 2, minHeight: 400 }}>
          
          {isEditing && (
              <Box borderBottom={1} borderColor="divider" mb={2}>
                  <Tabs value={tabIndex} onChange={(e, v) => setTabIndex(v)} aria-label="incident tabs" variant="scrollable" scrollButtons="auto">
                      <Tab label="جزئیات و ویرایش" sx={{ fontFamily: 'Vazirmatn' }} />
                      <Tab label="تخصیص منابع" sx={{ fontFamily: 'Vazirmatn' }} />
                      <Tab label="تاریخچه" sx={{ fontFamily: 'Vazirmatn' }} />
                  </Tabs>
              </Box>
          )}

          {/* TAB 0: Form / Details */}
          {tabIndex === 0 && (
          <Box mt={2}>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12 }}>
                 <Typography variant="subtitle2" color="primary" sx={{ fontFamily: 'Vazirmatn, sans-serif', mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                    اطلاعات پایه
                 </Typography>
              </Grid>
              
              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  label="عنوان حادثه"
                  fullWidth
                  required
                  variant="outlined"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  sx={{ '& .MuiInputBase-root, & .MuiInputLabel-root': { fontFamily: 'Vazirmatn, sans-serif' } }}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  label="نوع حادثه"
                  fullWidth
                  required
                  variant="outlined"
                  placeholder="مثال: آتش‌سوزی، سیل..."
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  sx={{ '& .MuiInputBase-root, & .MuiInputLabel-root': { fontFamily: 'Vazirmatn, sans-serif' } }}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  label="نام گزارش‌دهنده"
                  fullWidth
                  variant="outlined"
                  value={formData.reporter}
                  onChange={(e) => setFormData({ ...formData, reporter: e.target.value })}
                  sx={{ '& .MuiInputBase-root, & .MuiInputLabel-root': { fontFamily: 'Vazirmatn, sans-serif' } }}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <FormControl fullWidth>
                  <InputLabel sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>وضعیت گزارش</InputLabel>
                  <Select
                    value={formData.status}
                    label="وضعیت گزارش"
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    sx={{ fontFamily: 'Vazirmatn, sans-serif' }}
                  >
                    <MenuItem value="جدید" sx={{ fontFamily: 'Vazirmatn' }}>جدید</MenuItem>
                    <MenuItem value="در حال بررسی" sx={{ fontFamily: 'Vazirmatn' }}>در حال بررسی</MenuItem>
                    <MenuItem value="حل شده" sx={{ fontFamily: 'Vazirmatn' }}>حل شده</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              {/* Location Info */}
              <Grid size={{ xs: 12 }}>
                 <Box mt={2} borderTop={1} borderColor="grey.200" pt={2}>
                    <Typography variant="subtitle2" color="primary" sx={{ fontFamily: 'Vazirmatn, sans-serif', mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                       <MapPin size={16} /> موقعیت و آدرس
                    </Typography>
                 </Box>
              </Grid>

              <Grid size={{ xs: 6, md: 3 }}>
                <TextField
                  label="منطقه شهرداری"
                  fullWidth
                  variant="outlined"
                  placeholder="مثال: ۴"
                  value={formData.region}
                  onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                  sx={{ '& .MuiInputBase-root, & .MuiInputLabel-root': { fontFamily: 'Vazirmatn, sans-serif' } }}
                />
              </Grid>
              <Grid size={{ xs: 6, md: 3 }}>
                <TextField
                  label="محله"
                  fullWidth
                  variant="outlined"
                  value={formData.neighborhood}
                  onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                  sx={{ '& .MuiInputBase-root, & .MuiInputLabel-root': { fontFamily: 'Vazirmatn, sans-serif' } }}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  label="آدرس دقیق"
                  fullWidth
                  variant="outlined"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  sx={{ '& .MuiInputBase-root, & .MuiInputLabel-root': { fontFamily: 'Vazirmatn, sans-serif' } }}
                />
              </Grid>
              
              <Grid size={{ xs: 6 }}>
                 <TextField
                  label="عرض جغرافیایی"
                  fullWidth
                  variant="outlined"
                  dir="ltr"
                  value={formData.lat}
                  onChange={(e) => setFormData({ ...formData, lat: parseFloat(e.target.value) || 0 })}
                  sx={{ '& .MuiInputBase-root, & .MuiInputLabel-root': { fontFamily: 'Vazirmatn, sans-serif' } }}
                />
              </Grid>
              <Grid size={{ xs: 6 }}>
                 <TextField
                  label="طول جغرافیایی"
                  fullWidth
                  variant="outlined"
                  dir="ltr"
                  value={formData.lng}
                  onChange={(e) => setFormData({ ...formData, lng: parseFloat(e.target.value) || 0 })}
                  sx={{ '& .MuiInputBase-root, & .MuiInputLabel-root': { fontFamily: 'Vazirmatn, sans-serif' } }}
                />
              </Grid>
              
              <Grid size={{ xs: 12 }}>
                <Box height={300} width="100%" sx={{ border: '1px solid #e2e8f0', borderRadius: 2, overflow: 'hidden' }}>
                    <MapContainer 
                      center={[formData.lat || 34.64, formData.lng || 50.87]} 
                      zoom={13} 
                      style={{ height: '100%', width: '100%' }}
                    >
                      <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                      />
                      <LocationMarker setFormData={setFormData} />
                      {formData.lat && formData.lng && (
                        <Marker position={[formData.lat, formData.lng]} icon={redIcon} />
                      )}
                    </MapContainer>
                </Box>
                <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'Vazirmatn, sans-serif', mt: 1, display: 'block' }}>
                    برای انتخاب موقعیت روی نقشه کلیک کنید.
                </Typography>
              </Grid>
            </Grid>
          </Box>
          )}
          
          {/* TAB 1: Resources */}
          {tabIndex === 1 && renderResourcesTab()}

          {/* TAB 2: Timeline */}
          {tabIndex === 2 && renderTimelineTab()}

        </DialogContent>
        <DialogActions sx={{ p: 3, borderTop: '1px solid #e2e8f0' }}>
          <Button onClick={handleCloseDialog} color="inherit" sx={{ fontFamily: 'Vazirmatn', ml: 1 }}>
            انصراف
          </Button>
          <Button onClick={handleSave} variant="contained" color="primary" sx={{ fontFamily: 'Vazirmatn', px: 4 }}>
            {isEditing ? 'ذخیره تغییرات' : 'ثبت گزارش'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default IncidentsTable;