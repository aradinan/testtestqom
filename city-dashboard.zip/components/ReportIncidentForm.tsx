import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  TextField, 
  Button, 
  Box, 
  FormControl, 
  InputLabel, 
  Select, 
  MenuItem,
  SelectChangeEvent,
  CircularProgress,
  IconButton
} from '@mui/material';
import { MapPin, Crosshair } from 'lucide-react';
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet';
import L from 'leaflet';

// Define icon for the form map
const createIcon = (color: string) => new L.Icon({
    iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
});
const redIcon = createIcon('red');

interface ReportIncidentFormProps {
  onSubmit?: (data: { type: string; description: string; lat: number; lng: number }) => void;
  onCancel?: () => void;
}

// Component to handle map clicks and location
const LocationController = ({ position, setPosition, setOnLocate }: { 
    position: L.LatLngExpression | null, 
    setPosition: (pos: { lat: number, lng: number }) => void,
    setOnLocate: (cb: () => void) => void
}) => {
    const map = useMap();
    useMapEvents({
      click(e) {
        setPosition({ lat: e.latlng.lat, lng: e.latlng.lng });
      },
    });

    useEffect(() => {
        setOnLocate(() => {
            map.locate().on("locationfound", function (e) {
                setPosition({ lat: e.latlng.lat, lng: e.latlng.lng });
                map.flyTo(e.latlng, map.getZoom());
            });
        });
    }, [map, setPosition, setOnLocate]);

    return position ? <Marker position={position} icon={redIcon} /> : null;
};

const ReportIncidentForm: React.FC<ReportIncidentFormProps> = ({ onSubmit, onCancel }) => {
  const [type, setType] = useState('');
  const [description, setDescription] = useState('');
  const [loadingLocation, setLoadingLocation] = useState(false);
  const [location, setLocation] = useState<{ lat: number, lng: number } | null>(null);
  
  // Ref to hold the locate function
  const locateMeRef = React.useRef<() => void>(() => {});

  // Initialize with current location
  useEffect(() => {
    if ('geolocation' in navigator) {
        setLoadingLocation(true);
        navigator.geolocation.getCurrentPosition(
            (position) => {
                setLocation({
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                });
                setLoadingLocation(false);
            },
            (error) => {
                console.warn("Could not get initial location", error);
                setLocation({ lat: 34.64, lng: 50.87 }); 
                setLoadingLocation(false);
            }
        );
    } else {
        setLocation({ lat: 34.64, lng: 50.87 });
    }
  }, []);

  const handleTypeChange = (event: SelectChangeEvent) => {
    setType(event.target.value as string);
  };

  const handleSubmit = () => {
    if (!type) {
      alert('لطفا نوع حادثه را انتخاب کنید.');
      return;
    }
    if (!location) {
        alert('لطفا موقعیت حادثه را روی نقشه مشخص کنید.');
        return;
    }

    if (onSubmit) {
        onSubmit({ 
            type, 
            description, 
            lat: location.lat, 
            lng: location.lng 
        });
    }
  };

  return (
    <Box sx={{ p: 2, direction: 'rtl' }}>
      <Typography
        variant="h6"
        component="h2"
        gutterBottom
        fontWeight="bold"
        sx={{ fontFamily: 'Vazirmatn, sans-serif', mb: 2, color: '#1e293b' }}
      >
        گزارش حادثه جدید
      </Typography>

      <Box display="flex" flexDirection="column" gap={2}>
        <FormControl fullWidth size="small">
          <InputLabel id="incident-type-label" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>نوع حادثه</InputLabel>
          <Select
            labelId="incident-type-label"
            id="incident-type"
            value={type}
            label="نوع حادثه"
            onChange={handleTypeChange}
            sx={{ fontFamily: 'Vazirmatn, sans-serif' }}
          >
            <MenuItem value="آتش‌سوزی" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>آتش‌سوزی</MenuItem>
            <MenuItem value="تصادف" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>تصادف</MenuItem>
            <MenuItem value="ریزش آوار" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>ریزش آوار</MenuItem>
            <MenuItem value="نشت گاز" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>نشت گاز</MenuItem>
            <MenuItem value="آب‌گرفتگی" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>آب‌گرفتگی</MenuItem>
            <MenuItem value="سایر" sx={{ fontFamily: 'Vazirmatn, sans-serif' }}>سایر</MenuItem>
          </Select>
        </FormControl>

        <TextField
          id="description"
          label="توضیحات (اختیاری)"
          multiline
          rows={2}
          fullWidth
          size="small"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="جزئیات حادثه را شرح دهید..."
          variant="outlined"
          sx={{
            '& .MuiInputBase-root': { fontFamily: 'Vazirmatn, sans-serif' },
            '& .MuiInputLabel-root': { fontFamily: 'Vazirmatn, sans-serif' },
          }}
        />

        <Box sx={{ mt: 1 }}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                <Typography variant="caption" sx={{ fontFamily: 'Vazirmatn', color: 'text.secondary' }}>
                    موقعیت حادثه را روی نقشه مشخص کنید:
                </Typography>
                <Button 
                    size="small" 
                    startIcon={<Crosshair size={14} />} 
                    onClick={() => locateMeRef.current()}
                    sx={{ fontFamily: 'Vazirmatn', fontSize: '0.7rem' }}
                >
                    موقعیت من
                </Button>
            </Box>
            
            <Box 
                sx={{ 
                    height: 250, 
                    width: '100%', 
                    borderRadius: 2, 
                    overflow: 'hidden', 
                    border: '1px solid #e2e8f0',
                    position: 'relative'
                }}
            >
                {loadingLocation && (
                    <Box sx={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', bgcolor: 'rgba(255,255,255,0.7)', zIndex: 1000 }}>
                        <CircularProgress size={24} />
                    </Box>
                )}
                {location && (
                    <MapContainer 
                        center={[location.lat, location.lng]} 
                        zoom={14} 
                        style={{ height: '100%', width: '100%' }}
                    >
                        <TileLayer
                            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        />
                        <LocationController 
                            position={location} 
                            setPosition={setLocation} 
                            setOnLocate={(fn) => locateMeRef.current = fn}
                        />
                    </MapContainer>
                )}
            </Box>
        </Box>

        <Box display="flex" gap={2} mt={1}>
            {onCancel && (
                <Button 
                    variant="outlined" 
                    color="inherit" 
                    fullWidth 
                    onClick={onCancel}
                    sx={{ fontFamily: 'Vazirmatn, sans-serif' }}
                >
                    انصراف
                </Button>
            )}
            <Button
            variant="contained"
            color="error"
            size="large"
            fullWidth
            onClick={handleSubmit}
            disabled={!location || !type}
            startIcon={<MapPin />}
            sx={{ fontFamily: 'Vazirmatn, sans-serif', fontWeight: 'bold', py: 1.5 }}
            >
            ثبت گزارش
            </Button>
        </Box>
      </Box>
    </Box>
  );
};

export default ReportIncidentForm;