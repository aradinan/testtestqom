
import React from 'react';
import { Card, CardContent, Box, Typography } from '@mui/material';

// Helper for Persian Numbers
const toPersianDigits = (num: string | number | undefined | null) => {
  if (num === undefined || num === null) return '';
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, x => farsiDigits[parseInt(x)]);
};

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  iconBgColor: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, iconBgColor }) => {
  return (
    <Card 
      elevation={0}
      sx={{ 
        borderRadius: 4,
        height: '100%',
        border: '1px solid #f1f5f9',
        boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
        transition: 'transform 0.2s, box-shadow 0.2s',
        '&:hover': {
           transform: 'translateY(-2px)',
           boxShadow: '0 8px 16px rgba(0,0,0,0.08)'
        }
      }}
    >
      <CardContent sx={{ p: { xs: 2.5, md: 3 }, '&:last-child': { pb: { xs: 2.5, md: 3 } } }}>
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box display="flex" flexDirection="column" gap={0.5}>
            <Typography 
              variant="subtitle2" 
              color="text.secondary" 
              sx={{ 
                fontFamily: 'Vazirmatn, sans-serif', 
                fontWeight: 500,
                fontSize: '0.9rem'
              }}
            >
              {title}
            </Typography>
            <Typography 
              variant="h4" 
              fontWeight="bold" 
              color="text.primary"
              sx={{ 
                fontFamily: 'Vazirmatn, sans-serif', 
                fontSize: { xs: '1.75rem', md: '2rem' },
                lineHeight: 1
              }}
            >
              {toPersianDigits(value)}
            </Typography>
          </Box>
          <Box 
            sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center',
              width: 56,
              height: 56,
              borderRadius: '50%', // Circular icon background
              bgcolor: iconBgColor.replace('bg-', 'var(--tw-bg-opacity, 1) ').replace('-500', ''), // This relies on Tailwind classes being mapped or simple inline styles. Let's use sx for safety.
              className: `${iconBgColor} text-white`, // Keep tailwind for color if configured, else fallback
            }}
          >
             {React.cloneElement(icon as React.ReactElement<any>, { 
                fontSize: 'medium',
                sx: { fontSize: 28 }
            })}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

export default StatCard;
