
import React, { useState, useEffect } from 'react';
import { 
  Box, Typography, Checkbox, List, ListItem, ListItemButton, 
  ListItemIcon, ListItemText, LinearProgress, Paper, Divider, Chip, IconButton
} from '@mui/material';
import { Backpack, CheckCircle, Circle, Droplets, Utensils, Zap, FileText, BriefcaseMedical, X } from 'lucide-react';

// Helper for Persian Numbers
const toPersianDigits = (num: string | number) => {
  if (num === undefined || num === null) return '';
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, x => farsiDigits[parseInt(x)]);
};

const DEFAULT_ITEMS = [
  { id: 1, category: 'حیاتی', name: 'آب آشامیدنی (۳ لیتر برای هر نفر)', icon: <Droplets size={18} className="text-blue-500" /> },
  { id: 2, category: 'حیاتی', name: 'غذاهای کنسروی و خشک (برای ۳ روز)', icon: <Utensils size={18} className="text-orange-500" /> },
  { id: 3, category: 'تجهیزات', name: 'چراغ قوه + باتری اضافه', icon: <Zap size={18} className="text-yellow-500" /> },
  { id: 4, category: 'تجهیزات', name: 'رادیو جیبی (باتری‌خور)', icon: <Zap size={18} className="text-gray-500" /> },
  { id: 5, category: 'بهداشتی', name: 'جعبه کمک‌های اولیه', icon: <BriefcaseMedical size={18} className="text-red-500" /> },
  { id: 6, category: 'بهداشتی', name: 'داروهای خاص و شخصی', icon: <BriefcaseMedical size={18} className="text-red-400" /> },
  { id: 7, category: 'مدارک', name: 'کپی مدارک شناسایی و اسناد', icon: <FileText size={18} className="text-purple-500" /> },
  { id: 8, category: 'مدارک', name: 'پول نقد (اسکناس)', icon: <FileText size={18} className="text-green-500" /> },
  { id: 9, category: 'تجهیزات', name: 'سوت نجات', icon: <Zap size={18} className="text-gray-700" /> },
  { id: 10, category: 'تجهیزات', name: 'چاقو چندکاره / ابزار', icon: <Zap size={18} className="text-gray-600" /> },
];

interface SurvivalKitProps {
    onClose?: () => void;
}

const SurvivalKit: React.FC<SurvivalKitProps> = ({ onClose }) => {
  const [checkedItems, setCheckedItems] = useState<number[]>([]);

  // Load from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem('survival_kit_checked');
    if (saved) {
      setCheckedItems(JSON.parse(saved));
    }
  }, []);

  const handleToggle = (id: number) => {
    const newChecked = checkedItems.includes(id)
      ? checkedItems.filter(i => i !== id)
      : [...checkedItems, id];
    
    setCheckedItems(newChecked);
    localStorage.setItem('survival_kit_checked', JSON.stringify(newChecked));
  };

  const progress = (checkedItems.length / DEFAULT_ITEMS.length) * 100;

  return (
    <Box sx={{ direction: 'rtl', p: 1 }}>
      <Box display="flex" alignItems="flex-start" justifyContent="space-between" mb={3}>
        <Box display="flex" alignItems="center" gap={2}>
            <Box p={1.5} bgcolor="#e0f2fe" borderRadius="50%" color="#0284c7">
                <Backpack size={32} />
            </Box>
            <Box>
                <Typography variant="h6" fontWeight="bold" fontFamily="Vazirmatn">کوله نجات دیجیتال</Typography>
                <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn">وضعیت آمادگی شما: {toPersianDigits(Math.round(progress))}%</Typography>
                <LinearProgress 
                    variant="determinate" 
                    value={progress} 
                    sx={{ 
                        mt: 1, 
                        height: 8, 
                        borderRadius: 4,
                        width: 140,
                        '& .MuiLinearProgress-bar': {
                            bgcolor: progress < 50 ? '#ef4444' : (progress < 80 ? '#f97316' : '#22c55e')
                        }
                    }} 
                />
            </Box>
        </Box>
        {onClose && (
            <IconButton onClick={onClose} size="small">
                <X />
            </IconButton>
        )}
      </Box>

      <Paper elevation={0} variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden' }}>
        <List sx={{ p: 0 }}>
          {DEFAULT_ITEMS.map((item, index) => (
            <React.Fragment key={item.id}>
                {index > 0 && <Divider component="li" />}
                <ListItem disablePadding>
                <ListItemButton onClick={() => handleToggle(item.id)} dense>
                    <ListItemIcon sx={{ minWidth: 36 }}>
                    {checkedItems.includes(item.id) ? (
                        <CheckCircle className="text-green-500" size={22} />
                    ) : (
                        <Circle className="text-gray-300" size={22} />
                    )}
                    </ListItemIcon>
                    <ListItemText 
                        primary={
                            <Box display="flex" alignItems="center" gap={1}>
                                <Typography 
                                    fontFamily="Vazirmatn" 
                                    sx={{ 
                                        textDecoration: checkedItems.includes(item.id) ? 'line-through' : 'none',
                                        color: checkedItems.includes(item.id) ? 'text.disabled' : 'text.primary'
                                    }}
                                >
                                    {item.name}
                                </Typography>
                            </Box>
                        }
                    />
                    <Box display="flex" alignItems="center" gap={1}>
                        {item.icon}
                        <Chip label={item.category} size="small" sx={{ fontFamily: 'Vazirmatn', fontSize: '0.65rem', height: 20 }} />
                    </Box>
                </ListItemButton>
                </ListItem>
            </React.Fragment>
          ))}
        </List>
      </Paper>

      <Box mt={3} p={2} bgcolor="#f0f9ff" borderRadius={2} border="1px dashed #0284c7">
          <Typography variant="body2" color="#0369a1" fontFamily="Vazirmatn" textAlign="center">
              💡 نکته: کوله نجات باید در دسترس‌ترین مکان خانه (نزدیک خروجی) باشد و هر ۶ ماه یکبار تاریخ انقضای مواد غذایی چک شود.
          </Typography>
      </Box>
    </Box>
  );
};

export default SurvivalKit;
