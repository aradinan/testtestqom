
import React from 'react';
import { 
  Box, Typography, Accordion, AccordionSummary, AccordionDetails, 
  List, ListItem, ListItemIcon, ListItemText, Paper, IconButton
} from '@mui/material';
import { ChevronDown, AlertCircle, PlayCircle, Shield, MoveRight, X } from 'lucide-react';

const GUIDES = [
  {
    id: 'earthquake',
    title: 'اقدامات هنگام زلزله',
    color: '#ef4444',
    content: [
      'اگر داخل ساختمان هستید: پناه گرفتن زیر میز محکم یا گوشه دیوارهای داخلی.',
      'از پنجره‌ها، آینه‌ها و کمدها دور شوید.',
      'اگر بیرون هستید: از ساختمان‌ها، درختان و تیرهای برق فاصله بگیرید.',
      'از آسانسور استفاده نکنید.',
      'سر و گردن خود را با دست‌ها بپوشانید.'
    ]
  },
  {
    id: 'fire',
    title: 'اقدامات هنگام آتش‌سوزی',
    color: '#f97316',
    content: [
      'بلافاصله با ۱۲۵ تماس بگیرید.',
      'اگر دود غلیظ است، سینه خیز حرکت کنید (هوای تمیز نزدیک زمین است).',
      'قبل از باز کردن درب، حرارت آن را با پشت دست چک کنید.',
      'اگر لباستان آتش گرفت: بایستید، بخوابید و غلت بزنید.',
      'هرگز از آب برای خاموش کردن آتش روغن یا برق استفاده نکنید.'
    ]
  },
  {
    id: 'flood',
    title: 'اقدامات هنگام سیلاب',
    color: '#3b82f6',
    content: [
      'به مناطق مرتفع بروید.',
      'از راه رفتن در آب سیل خودداری کنید (۱۵ سانتیمتر آب تعادل را به هم می‌زند).',
      'با خودرو وارد سیلاب نشوید.',
      'جریان برق و گاز منزل را قطع کنید.',
      'به هشدارهای رادیو و مقامات محلی گوش دهید.'
    ]
  }
];

interface EducationHubProps {
  onClose?: () => void;
}

const EducationHub: React.FC<EducationHubProps> = ({ onClose }) => {
  return (
    <Box sx={{ direction: 'rtl', p: 1 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
           <Typography variant="h6" fontWeight="bold" fontFamily="Vazirmatn">
            آموزش و دانشنامه بحران
           </Typography>
           {onClose && (
               <IconButton onClick={onClose} size="small">
                   <X />
               </IconButton>
           )}
      </Box>

      <Box display="flex" gap={2} mb={4} overflow="auto" pb={1}>
         <Paper 
            elevation={0} 
            sx={{ 
                minWidth: 140, p: 2, bgcolor: '#eff6ff', borderRadius: 2, cursor: 'pointer',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1
            }}
         >
             <PlayCircle className="text-blue-600" size={32} />
             <Typography fontFamily="Vazirmatn" variant="subtitle2" fontWeight="bold">ویدیو آموزشی</Typography>
         </Paper>
         <Paper 
            elevation={0} 
            sx={{ 
                minWidth: 140, p: 2, bgcolor: '#f0fdf4', borderRadius: 2, cursor: 'pointer',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1
            }}
         >
             <Shield className="text-green-600" size={32} />
             <Typography fontFamily="Vazirmatn" variant="subtitle2" fontWeight="bold">نقشه امن</Typography>
         </Paper>
      </Box>

      <Typography variant="subtitle2" color="text.secondary" fontFamily="Vazirmatn" mb={2}>راهنماهای فوری</Typography>

      {GUIDES.map((guide) => (
        <Accordion key={guide.id} disableGutters elevation={0} sx={{ mb: 1, border: '1px solid #e2e8f0', borderRadius: '8px !important', '&:before': { display: 'none' } }}>
          <AccordionSummary expandIcon={<ChevronDown size={20} />} sx={{ flexDirection: 'row-reverse' }}>
            <Box display="flex" alignItems="center" gap={1.5} width="100%">
               <AlertCircle size={20} color={guide.color} />
               <Typography fontFamily="Vazirmatn" fontWeight="bold">{guide.title}</Typography>
            </Box>
          </AccordionSummary>
          <AccordionDetails sx={{ bgcolor: '#fafafa', borderTop: '1px solid #f1f5f9' }}>
             <List dense>
                {guide.content.map((item, idx) => (
                    <ListItem key={idx} alignItems="flex-start">
                        <ListItemIcon sx={{ minWidth: 24, mt: 0.5 }}>
                            <MoveRight size={16} className="text-gray-400" />
                        </ListItemIcon>
                        <ListItemText 
                            primary={<Typography variant="body2" fontFamily="Vazirmatn" lineHeight={1.8}>{item}</Typography>} 
                        />
                    </ListItem>
                ))}
             </List>
          </AccordionDetails>
        </Accordion>
      ))}
    </Box>
  );
};

export default EducationHub;
