
import React, { useState, useEffect } from 'react';
import { 
  Paper, 
  Typography, 
  TextField, 
  Button, 
  Box, 
  Dialog, 
  DialogTitle, 
  DialogContent, 
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  List,
  ListItem,
  Chip,
  Divider,
  IconButton,
  Grid,
  Alert as MuiAlert,
  useTheme,
  useMediaQuery
} from '@mui/material';
import { Send, Bell, X, Users, History, Radio } from 'lucide-react';
import { db } from '../db';

// Helper for Persian Numbers
const toPersianDigits = (num: string | number) => {
  if (num === undefined || num === null) return '';
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, x => farsiDigits[parseInt(x)]);
};

const AlertForm: React.FC = () => {
  const [open, setOpen] = useState(false);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [message, setMessage] = useState('');
  const [targetType, setTargetType] = useState('general');
  const [level, setLevel] = useState('info');
  const [customRegion, setCustomRegion] = useState('');
  
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));

  const refreshAlerts = () => {
    const data = db.getAlerts();
    setAlerts([...data].sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
  };

  useEffect(() => {
    if (open) {
      refreshAlerts();
    }
  }, [open]);

  const handleSend = () => {
    if (!message) return;

    let targetDescription = 'همه شهروندان';
    if (targetType === 'region') targetDescription = customRegion ? `منطقه/خیابان: ${customRegion}` : 'منطقه خاص';
    if (targetType === 'jamkaran') targetDescription = 'اطراف جمکران';
    if (targetType === 'imam_khomeini') targetDescription = 'شهرک امام خمینی';

    const newAlert = {
      message,
      level,
      target: targetType,
      targetDescription,
      region: customRegion,
      createdAt: new Date().toISOString()
    };

    db.addAlert(newAlert);
    refreshAlerts();
    setMessage('');
    setCustomRegion('');
  };

  const getLevelColor = (l: string) => {
    switch(l) {
      case 'critical': return 'error';
      case 'warning': return 'warning';
      case 'info': return 'info';
      default: return 'default';
    }
  };

  const getLevelLabel = (l: string) => {
      switch(l) {
          case 'critical': return 'خطر فوری';
          case 'warning': return 'هشدار';
          case 'info': return 'اطلاع‌رسانی';
          default: return 'عمومی';
      }
  }

  return (
    <>
      {/* Control Card Button */}
      <Paper 
        elevation={0}
        onClick={() => setOpen(true)}
        sx={{ 
          p: 3, 
          height: '100%', 
          borderRadius: 3, 
          cursor: 'pointer',
          border: '1px solid #fee2e2',
          background: 'linear-gradient(135deg, #fff1f2 0%, #fff 100%)',
          transition: 'all 0.3s ease',
          '&:hover': {
            transform: 'translateY(-4px)',
            boxShadow: '0 10px 25px -5px rgba(220, 38, 38, 0.15)',
            borderColor: '#fca5a5'
          },
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 2,
          position: 'relative',
          overflow: 'hidden'
        }}
      >
        <Box 
            position="absolute" 
            top={-10} 
            right={-10} 
            width={80} 
            height={80} 
            borderRadius="50%" 
            bgcolor="#fecaca" 
            sx={{ opacity: 0.3 }}
        />
        
        <Box 
          p={2} 
          bgcolor="#fee2e2" 
          color="#dc2626" 
          borderRadius="50%" 
          boxShadow="0 4px 6px -1px rgba(220, 38, 38, 0.1)"
        >
            <Radio size={32} className="animate-pulse" />
        </Box>
        
        <Box textAlign="center">
            <Typography variant="h6" fontWeight="bold" fontFamily="Vazirmatn" color="#991b1b">
            ارسال هشدار همگانی
            </Typography>
            <Typography variant="body2" color="#b91c1c" fontFamily="Vazirmatn" mt={0.5}>
            پخش پیام اضطراری در مناطق
            </Typography>
        </Box>
        
        <Button 
            variant="contained" 
            color="error" 
            size="small"
            sx={{ 
                fontFamily: 'Vazirmatn', 
                borderRadius: 2, 
                px: 3,
                bgcolor: '#dc2626',
                '&:hover': { bgcolor: '#b91c1c' }
            }}
        >
            ارسال پیام
        </Button>
      </Paper>

      {/* Modal */}
      <Dialog 
        open={open} 
        onClose={() => setOpen(false)} 
        fullWidth 
        maxWidth="md" 
        fullScreen={fullScreen}
        dir="rtl"
      >
        <DialogTitle sx={{ fontFamily: 'Vazirmatn', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', bgcolor: '#f8fafc' }}>
          <Box display="flex" alignItems="center" gap={1}>
             <Bell className="text-red-500" />
             <Typography variant="h6" fontFamily="Vazirmatn" fontWeight="bold">مدیریت هشدارهای عمومی</Typography>
          </Box>
          <IconButton onClick={() => setOpen(false)} size="small"><X /></IconButton>
        </DialogTitle>
        <DialogContent sx={{ p: 0 }}>
           <Grid container sx={{ minHeight: { md: 500 }, height: '100%' }}>
              {/* Left Side: Form */}
              <Grid size={{ xs: 12, md: 7 }} sx={{ p: 3, display: 'flex', flexDirection: 'column', gap: 3 }}>
                 <MuiAlert severity="info" sx={{ fontFamily: 'Vazirmatn', '& .MuiAlert-icon': { mr: 1, ml: 0 } }}>
                    پیام ارسالی به صورت نوتیفیکیشن و پیامک برای شهروندان در محدوده انتخاب شده ارسال خواهد شد.
                 </MuiAlert>

                 <Box display="flex" flexDirection="column" gap={2.5}>
                    <FormControl fullWidth size="medium">
                      <InputLabel sx={{ fontFamily: 'Vazirmatn' }}>مخاطبین هدف</InputLabel>
                      <Select 
                        value={targetType} 
                        label="مخاطبین هدف" 
                        onChange={(e) => setTargetType(e.target.value)}
                        sx={{ fontFamily: 'Vazirmatn' }}
                      >
                        <MenuItem value="general" sx={{ fontFamily: 'Vazirmatn' }}>همه شهروندان (عمومی)</MenuItem>
                        <MenuItem value="region" sx={{ fontFamily: 'Vazirmatn' }}>ساکنین یک منطقه/خیابان خاص</MenuItem>
                        <MenuItem value="jamkaran" sx={{ fontFamily: 'Vazirmatn' }}>اطراف جمکران (شعاع ۲ کیلومتر)</MenuItem>
                        <MenuItem value="imam_khomeini" sx={{ fontFamily: 'Vazirmatn' }}>ساکنین شهرک امام خمینی</MenuItem>
                      </Select>
                    </FormControl>

                    {targetType === 'region' && (
                       <TextField 
                         label="نام منطقه یا خیابان" 
                         size="medium" 
                         fullWidth 
                         value={customRegion}
                         onChange={(e) => setCustomRegion(e.target.value)}
                         placeholder="مثال: منطقه ۴، خیابان صفاییه"
                         sx={{ '& .MuiInputBase-root': { fontFamily: 'Vazirmatn' }, '& .MuiInputLabel-root': { fontFamily: 'Vazirmatn' } }}
                       />
                    )}

                    <Box>
                        <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn" gutterBottom display="block">سطح اهمیت</Typography>
                        <Box display="flex" gap={1}>
                            {['info', 'warning', 'critical'].map((l) => (
                                <Chip 
                                    key={l}
                                    label={getLevelLabel(l)}
                                    onClick={() => setLevel(l)}
                                    color={l === level ? getLevelColor(l) as any : 'default'}
                                    variant={l === level ? 'filled' : 'outlined'}
                                    sx={{ 
                                        fontFamily: 'Vazirmatn', 
                                        flex: 1, 
                                        height: 36,
                                        borderColor: l === level ? 'transparent' : '#e2e8f0'
                                    }}
                                />
                            ))}
                        </Box>
                    </Box>

                    <TextField 
                      label="متن هشدار" 
                      multiline 
                      rows={5} 
                      fullWidth 
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="متن پیام اضطراری را اینجا بنویسید..."
                      sx={{ '& .MuiInputBase-root': { fontFamily: 'Vazirmatn' }, '& .MuiInputLabel-root': { fontFamily: 'Vazirmatn' } }}
                    />
                 </Box>
              </Grid>

              {/* Right Side: History */}
              <Grid size={{ xs: 12, md: 5 }} sx={{ bgcolor: '#f8fafc', borderRight: { md: '1px solid #e2e8f0' }, borderTop: { xs: '1px solid #e2e8f0', md: 'none' }, display: 'flex', flexDirection: 'column' }}>
                 <Box p={2} borderBottom="1px solid #e2e8f0" bgcolor="white">
                     <Typography variant="subtitle2" fontWeight="bold" color="text.secondary" sx={{ fontFamily: 'Vazirmatn', display: 'flex', alignItems: 'center', gap: 1 }}>
                        <History size={16} /> تاریخچه هشدارها
                     </Typography>
                 </Box>
                 
                 <List sx={{ overflow: 'auto', flex: 1, p: 2, maxHeight: { xs: 300, md: 'auto' } }}>
                    {alerts.length === 0 ? (
                      <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center" height={200} sx={{ opacity: 0.5 }}>
                          <Bell size={32} />
                          <Typography variant="caption" fontFamily="Vazirmatn" mt={1}>لیست خالی است</Typography>
                      </Box>
                    ) : (
                      alerts.map((alert) => (
                        <Paper key={alert.id} elevation={0} sx={{ mb: 2, border: '1px solid #e2e8f0', borderRadius: 2, overflow: 'hidden', bgcolor: 'white' }}>
                           <ListItem sx={{ flexDirection: 'column', alignItems: 'flex-start', p: 1.5 }}>
                              <Box display="flex" justifyContent="space-between" width="100%" mb={1} alignItems="center">
                                 <Chip 
                                    label={getLevelLabel(alert.level)} 
                                    color={getLevelColor(alert.level) as any} 
                                    size="small" 
                                    sx={{ fontFamily: 'Vazirmatn', height: 20, fontSize: '0.7rem', fontWeight: 'bold' }}
                                 />
                                 <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn">
                                     {new Date(alert.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                                 </Typography>
                              </Box>
                              <Typography variant="body2" sx={{ fontFamily: 'Vazirmatn', mb: 1, lineHeight: 1.6, fontSize: '0.85rem' }}>
                                 {alert.message}
                              </Typography>
                              <Box display="flex" alignItems="center" gap={0.5} width="100%">
                                 <Users size={12} className="text-gray-400" />
                                 <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn" noWrap>
                                    {alert.targetDescription || (alert.region ? `منطقه ${alert.region}` : 'عمومی')}
                                 </Typography>
                              </Box>
                           </ListItem>
                        </Paper>
                      ))
                    )}
                 </List>
              </Grid>
           </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: '1px solid #e2e8f0' }}>
            <Button onClick={() => setOpen(false)} color="inherit" sx={{ fontFamily: 'Vazirmatn' }}>انصراف</Button>
            <Button 
                variant="contained" 
                color="error"
                onClick={handleSend}
                disabled={!message}
                startIcon={<Send size={18} />}
                sx={{ fontFamily: 'Vazirmatn', px: 3 }}
            >
                ارسال و انتشار
            </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default AlertForm;