
import React, { useState, useEffect, useRef } from 'react';
import { 
  Box, Paper, Typography, List, ListItem, ListItemButton, ListItemAvatar, Avatar, ListItemText, 
  Chip, TextField, IconButton, Badge, MenuItem, Select, FormControl, Divider, Grid, useTheme, useMediaQuery
} from '@mui/material';
import { Send, User, MapPin, Search, MessageCircle, MoreVertical, Phone, ArrowRight } from 'lucide-react';
import { db } from '../db';
import { MapContainer, TileLayer, Marker } from 'react-leaflet';
import L from 'leaflet';

// Icons
const redIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Helper for Persian Numbers
const toPersianDigits = (num: string | number) => {
  if (num === undefined || num === null) return '';
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, x => farsiDigits[parseInt(x)]);
};

const SupportMonitor = () => {
  const [requests, setRequests] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [replyText, setReplyText] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const chatEndRef = useRef<HTMLDivElement>(null);
  
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  useEffect(() => {
    // Poll for updates
    const loadData = () => {
        const data = db.getSupportRequests();
        let filtered = data;
        
        if (filterStatus !== 'all') {
            filtered = data.filter((r: any) => r.status === filterStatus);
        }

        setRequests(filtered.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    };
    
    loadData();
    const interval = setInterval(loadData, 3000);
    return () => clearInterval(interval);
  }, [filterStatus]);

  useEffect(() => {
      if (selectedId && chatEndRef.current) {
          chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
      }
  }, [requests, selectedId]);

  const handleSend = () => {
      if (!selectedId || !replyText.trim()) return;
      db.addSupportMessage(selectedId, { sender: 'support', text: replyText });
      setReplyText('');
  };

  const handleStatusChange = (id: number, newStatus: string) => {
      db.updateSupportStatus(id, newStatus);
      const updated = requests.map(r => r.id === id ? { ...r, status: newStatus } : r);
      setRequests(updated);
  };

  const handleBackToList = () => {
      setSelectedId(null);
  };

  const selectedRequest = requests.find(r => r.id === selectedId);

  return (
    <Paper 
        elevation={0} 
        sx={{ 
            overflow: 'hidden', 
            direction: 'rtl', 
            borderRadius: 3, 
            border: '1px solid #e2e8f0', 
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)',
            height: 450, // Reduced height for stretched look
            display: 'flex',
            flexDirection: 'column'
        }}
    >
       <Grid container sx={{ flex: 1, height: '100%' }}>
           {/* List Panel */}
           <Grid size={{ xs: 12, md: 3 }} sx={{ 
               borderLeft: { md: '1px solid #e2e8f0' }, 
               bgcolor: '#f8fafc', 
               display: { xs: selectedId ? 'none' : 'flex', md: 'flex' }, // Hide on mobile if chat selected
               flexDirection: 'column', 
               height: '100%' 
           }}>
               <Box p={2} borderBottom={1} borderColor="divider" bgcolor="white">
                   <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                       <Typography variant="subtitle2" fontFamily="Vazirmatn" fontWeight="bold">پیام‌های شهروندی</Typography>
                       <Chip 
                        label={toPersianDigits(requests.length)} 
                        size="small" 
                        sx={{ bgcolor: '#eff6ff', color: '#3b82f6', fontFamily: 'Vazirmatn', fontWeight: 'bold', height: 20, fontSize: '0.75rem' }} 
                       />
                   </Box>
                   
                   <FormControl fullWidth size="small">
                        <Select
                            value={filterStatus}
                            onChange={(e) => setFilterStatus(e.target.value)}
                            sx={{ fontFamily: 'Vazirmatn', bgcolor: 'white', fontSize: '0.85rem', height: 36 }}
                            displayEmpty
                            renderValue={(val) => {
                                if (val === 'all') return 'همه پیام‌ها';
                                if (val === 'open') return 'فقط باز';
                                return 'فقط بسته شده';
                            }}
                        >
                            <MenuItem value="all" sx={{ fontFamily: 'Vazirmatn' }}>همه پیام‌ها</MenuItem>
                            <MenuItem value="open" sx={{ fontFamily: 'Vazirmatn' }}>باز (نیازمند پاسخ)</MenuItem>
                            <MenuItem value="closed" sx={{ fontFamily: 'Vazirmatn' }}>بسته شده</MenuItem>
                        </Select>
                    </FormControl>
               </Box>

               <List sx={{ overflowY: 'auto', flexGrow: 1, p: 1 }}>
                   {requests.length === 0 ? (
                        <Box p={4} textAlign="center" color="text.secondary" display="flex" flexDirection="column" alignItems="center">
                            <MessageCircle size={32} opacity={0.3} />
                            <Typography variant="body2" fontFamily="Vazirmatn" mt={1}>پیامی یافت نشد</Typography>
                        </Box>
                   ) : (
                       requests.map((req) => (
                       <ListItem 
                          key={req.id} 
                          disablePadding
                          sx={{ mb: 1 }}
                       >
                           <ListItemButton
                               onClick={() => setSelectedId(req.id)}
                               selected={selectedId === req.id}
                               sx={{ 
                                  borderRadius: 2,
                                  transition: 'all 0.2s',
                                  border: selectedId === req.id ? '1px solid #bfdbfe' : '1px solid transparent',
                                  bgcolor: selectedId === req.id ? '#eff6ff !important' : 'transparent',
                                  '&:hover': { bgcolor: 'white', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }
                               }}
                           >
                               <ListItemAvatar sx={{ minWidth: 40 }}>
                                   <Badge
                                     overlap="circular"
                                     anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                                     variant="dot"
                                     color={req.status === 'open' ? 'error' : 'success'}
                                   >
                                       <Avatar sx={{ width: 32, height: 32, bgcolor: '#fff', border: '1px solid #e2e8f0', color: '#64748b' }}>
                                           <User size={16} />
                                       </Avatar>
                                   </Badge>
                               </ListItemAvatar>
                               <ListItemText 
                                  primary={
                                      <Box display="flex" justifyContent="space-between" alignItems="center">
                                          <Typography variant="subtitle2" fontFamily="Vazirmatn" fontWeight="bold" color="text.primary" fontSize="0.85rem">{req.user}</Typography>
                                          <Typography variant="caption" color="text.secondary" fontSize="0.65rem">{new Date(req.createdAt).toLocaleTimeString('fa-IR', {hour: '2-digit', minute:'2-digit'})}</Typography>
                                      </Box>
                                  }
                                  secondary={
                                      <Typography 
                                        variant="caption" 
                                        color="text.secondary" 
                                        fontFamily="Vazirmatn" 
                                        noWrap 
                                        display="block" 
                                        sx={{ mt: 0.5 }}
                                      >
                                          {req.messages[req.messages.length - 1]?.text}
                                      </Typography>
                                  }
                               />
                           </ListItemButton>
                       </ListItem>
                       ))
                   )}
               </List>
           </Grid>

           {/* Chat Panel */}
           <Grid size={{ xs: 12, md: 9 }} sx={{ 
               display: { xs: selectedId ? 'flex' : 'none', md: 'flex' }, // Show only when selected on mobile
               flexDirection: 'column', 
               bgcolor: 'white', 
               height: '100%' 
           }}>
               {selectedRequest ? (
                   <>
                       {/* Chat Header */}
                       <Box p={1.5} borderBottom={1} borderColor="divider" display="flex" justifyContent="space-between" alignItems="center" bgcolor="white">
                           <Box display="flex" alignItems="center" gap={2}>
                               {isMobile && (
                                   <IconButton onClick={handleBackToList} size="small" sx={{ color: 'text.secondary' }}>
                                       <ArrowRight size={20} />
                                   </IconButton>
                               )}
                               <Box display="flex" alignItems="center" gap={1.5}>
                                   <Avatar sx={{ width: 36, height: 36, bgcolor: '#eff6ff', color: '#3b82f6' }}>{selectedRequest.user.charAt(0)}</Avatar>
                                   <Box>
                                       <Typography variant="subtitle2" fontFamily="Vazirmatn" fontWeight="bold">
                                           {selectedRequest.user}
                                       </Typography>
                                       <Box display="flex" alignItems="center" gap={1}>
                                           <Box width={6} height={6} borderRadius="50%" bgcolor={selectedRequest.status === 'open' ? '#ef4444' : '#22c55e'} />
                                           <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn">
                                               {selectedRequest.status === 'open' ? 'منتظر پاسخ' : 'پاسخ داده شده'}
                                           </Typography>
                                       </Box>
                                   </Box>
                               </Box>
                           </Box>
                           
                           <Box display="flex" gap={1} alignItems="center">
                                <FormControl size="small" sx={{ minWidth: { xs: 100, sm: 140 } }}>
                                    <Select
                                        value={selectedRequest.status}
                                        onChange={(e) => handleStatusChange(selectedRequest.id, e.target.value)}
                                        sx={{ height: 32, fontFamily: 'Vazirmatn', fontSize: '0.8rem', borderRadius: 2 }}
                                    >
                                        <MenuItem value="open" sx={{ fontFamily: 'Vazirmatn' }}>باز</MenuItem>
                                        <MenuItem value="investigating" sx={{ fontFamily: 'Vazirmatn' }}>در حال بررسی</MenuItem>
                                        <MenuItem value="closed" sx={{ fontFamily: 'Vazirmatn' }}>بسته شده</MenuItem>
                                    </Select>
                                </FormControl>
                           </Box>
                       </Box>

                       {/* Messages Area */}
                       <Box flex={1} overflow="auto" p={2} display="flex" flexDirection="column" gap={1.5} bgcolor="#f8fafc">
                           {selectedRequest.messages.map((msg: any) => {
                               const isSupport = msg.sender === 'support';
                               const isSystem = msg.sender === 'system';
                               
                               return (
                                   <Box 
                                       key={msg.id} 
                                       display="flex" 
                                       justifyContent={isSupport ? 'flex-end' : (isSystem ? 'center' : 'flex-start')}
                                   >
                                       {!isSupport && !isSystem && (
                                           <Avatar sx={{ width: 24, height: 24, mr: 1, bgcolor: '#e2e8f0', fontSize: '0.8rem', color: '#64748b' }}>
                                               <User size={14} />
                                           </Avatar>
                                       )}
                                       
                                       <Box maxWidth="85%">
                                           <Paper 
                                               elevation={0}
                                               sx={{ 
                                                   p: 1.5,
                                                   py: 1, 
                                                   bgcolor: isSupport ? '#3b82f6' : (isSystem ? 'transparent' : 'white'),
                                                   color: isSupport ? 'white' : 'text.primary',
                                                   borderRadius: 2,
                                                   borderTopRightRadius: isSupport ? 0 : 2,
                                                   borderTopLeftRadius: !isSupport && !isSystem ? 0 : 2,
                                                   boxShadow: isSystem ? 'none' : '0 1px 2px rgba(0,0,0,0.05)',
                                                   border: isSystem ? '1px dashed #cbd5e1' : (isSupport ? 'none' : '1px solid #e2e8f0')
                                               }}
                                           >
                                               <Typography variant="body2" fontFamily="Vazirmatn" sx={{ whiteSpace: 'pre-line', fontSize: '0.9rem' }}>{msg.text}</Typography>
                                           </Paper>
                                           {!isSystem && (
                                               <Typography variant="caption" display="block" textAlign={isSupport ? 'left' : 'right'} sx={{ color: '#94a3b8', mt: 0.25, fontSize: '0.65rem' }}>
                                                   {msg.time}
                                               </Typography>
                                           )}
                                       </Box>
                                   </Box>
                               );
                           })}
                           <div ref={chatEndRef} />
                       </Box>

                       {/* Input Area */}
                       <Box p={2} borderTop={1} borderColor="divider" display="flex" gap={1.5} bgcolor="white" alignItems="flex-end" sx={{ flexShrink: 0 }}>
                           <TextField 
                               fullWidth 
                               multiline
                               maxRows={2}
                               size="small" 
                               placeholder="پاسخ خود را بنویسید..." 
                               value={replyText}
                               onChange={(e) => setReplyText(e.target.value)}
                               onKeyPress={(e) => {
                                   if (e.key === 'Enter' && !e.shiftKey) {
                                       e.preventDefault();
                                       handleSend();
                                   }
                               }}
                               disabled={selectedRequest.status === 'closed'}
                               sx={{ 
                                   '& .MuiOutlinedInput-root': { 
                                       fontFamily: 'Vazirmatn',
                                       borderRadius: 3,
                                       bgcolor: '#f8fafc'
                                   } 
                               }}
                           />
                           <IconButton 
                            color="primary" 
                            onClick={handleSend} 
                            disabled={!replyText.trim() || selectedRequest.status === 'closed'}
                            sx={{ 
                                bgcolor: '#3b82f6', 
                                color: 'white', 
                                width: 40, 
                                height: 40, 
                                '&:hover': { bgcolor: '#2563eb' },
                                '&.Mui-disabled': { bgcolor: '#e2e8f0', color: '#94a3b8' }
                            }}
                           >
                               <Send size={18} />
                           </IconButton>
                       </Box>
                   </>
               ) : (
                   <Box display="flex" alignItems="center" justifyContent="center" height="100%" color="text.secondary" flexDirection="column" bgcolor="#f8fafc">
                       <Box p={3} bgcolor="white" borderRadius="50%" mb={2} boxShadow="0 2px 4px rgba(0,0,0,0.05)">
                            <MessageCircle size={40} className="text-blue-500" />
                       </Box>
                       <Typography variant="h6" fontFamily="Vazirmatn" fontWeight="bold">مرکز پیام</Typography>
                       <Typography variant="body2" fontFamily="Vazirmatn" color="text.secondary">برای شروع گفتگو، یک درخواست را انتخاب کنید</Typography>
                   </Box>
               )}
           </Grid>
       </Grid>
    </Paper>
  );
};

export default SupportMonitor;
