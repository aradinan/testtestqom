
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Box, 
  Typography, 
  Fab, 
  Paper, 
  Dialog, 
  Drawer, 
  List, 
  ListItem, 
  Divider, 
  Chip, 
  IconButton,
  Snackbar,
  Alert,
  Button,
  Stack,
  Card,
  CardActionArea,
  TextField,
  CircularProgress,
  Avatar,
  Grid,
  Fade,
  LinearProgress
} from '@mui/material';
import { 
  ShieldCheck, 
  AlertTriangle, 
  ClipboardList, 
  X, 
  MapPin, 
  Navigation, 
  Crosshair,
  Clock,
  Map as MapIcon,
  LayoutList,
  StopCircle,
  PhoneCall,
  Send,
  Headphones,
  Info,
  Menu,
  Backpack,
  Home,
  BookOpen,
  ChevronRight,
  Bell,
  ThermometerSun,
  Activity
} from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, CircleMarker, useMap, Polyline } from 'react-leaflet';
import L from 'leaflet';
import axios from 'axios';
import ReportIncidentForm from '../components/ReportIncidentForm';
import { db } from '../db';
import SurvivalKit from '../components/SurvivalKit';
import RiskAssessment from '../components/RiskAssessment';
import EducationHub from '../components/EducationHub';

// Define icons
const createIcon = (color: string) => new L.Icon({
  iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const redIcon = createIcon('red');
const blueIcon = createIcon('blue');

// Helper for Persian Numbers
const toPersianDigits = (num: string | number) => {
  if (num === undefined || num === null) return '';
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, x => farsiDigits[parseInt(x)]);
};

// Helper to format duration
const formatDuration = (seconds: number) => {
  const mins = Math.round(seconds / 60);
  if (mins < 60) return `${toPersianDigits(mins)} دقیقه`;
  const hours = Math.floor(mins / 60);
  const remainingMins = mins % 60;
  return `${toPersianDigits(hours)} ساعت و ${toPersianDigits(remainingMins)} دقیقه`;
};

// Helper to format distance
const formatDistance = (meters: number) => {
  if (meters < 1000) return `${toPersianDigits(Math.round(meters))} متر`;
  return `${toPersianDigits((meters / 1000).toFixed(1))} کیلومتر`;
};

// Map Controller
const MapController = ({ center, zoom }: { center: {lat: number, lng: number} | null, zoom: number }) => {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.flyTo([center.lat, center.lng], zoom, { duration: 1.5 });
    }
  }, [center, zoom, map]);
  return null;
};

interface Incident {
  id: number | string;
  lat: number;
  lng: number;
  title: string;
  type: string;
  status?: string;
  reporter?: string;
  address?: string;
}

interface Shelter {
  id: number | string;
  lat: number;
  lng: number;
  name: string;
  capacity: number;
  status?: string;
}

interface RouteInfo {
  distance: number; // meters
  duration: number; // seconds
}

interface AlertData {
  id: number;
  message: string;
  level: 'info' | 'warning' | 'critical';
  target: string;
  region?: string;
  createdAt: string;
}

interface ChatMessage {
    id: number;
    text: string;
    sender: 'user' | 'support' | 'system';
    time: string;
}

interface CitizenHomeProps {
  alerts?: AlertData[];
  incidents: Incident[];
  shelters: Shelter[];
  onSafeClick?: (data: { lat: number; lng: number; name?: string }) => void;
  onReportIncident?: (data: { type: string; description: string; lat: number; lng: number }) => void;
  onDeleteReport?: (id: number) => void;
}

const CitizenHome: React.FC<CitizenHomeProps> = ({ 
  alerts = [], 
  incidents, 
  shelters, 
  onSafeClick, 
  onReportIncident,
  onDeleteReport
}) => {
  const [reportOpen, setReportOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [showMap, setShowMap] = useState(false);
  
  // Feature Modals
  const [survivalOpen, setSurvivalOpen] = useState(false);
  const [riskOpen, setRiskOpen] = useState(false);
  const [eduOpen, setEduOpen] = useState(false);
  
  // Safe Dialog State
  const [safeDialogOpen, setSafeDialogOpen] = useState(false);
  const [safeName, setSafeName] = useState('');
  const [safeLoading, setSafeLoading] = useState(false);
  
  // Chat State
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [messageInput, setMessageInput] = useState('');
  const [currentRequestId, setCurrentRequestId] = useState<number | null>(null);
  
  // Risk Assessment State
  const [riskResult, setRiskResult] = useState<{ score: number, date: string } | null>(null);

  // Use a ref to access the latest currentRequestId inside async callbacks
  const currentRequestIdRef = useRef<number | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Map State
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  const [mapCenter, setMapCenter] = useState<{lat: number, lng: number} | null>(null);
  const [mapZoom, setMapZoom] = useState(13);
  
  // Routing State
  const [isNavigating, setIsNavigating] = useState(false);
  const [routePath, setRoutePath] = useState<[number, number][] | null>(null);
  const [targetShelter, setTargetShelter] = useState<Shelter | null>(null);
  const [targetIncident, setTargetIncident] = useState<Incident | null>(null);
  const [routeInfo, setRouteInfo] = useState<RouteInfo | null>(null);
  
  // Notification State
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState<'success' | 'info' | 'warning' | 'error'>('info');

  useEffect(() => {
    // Get user location on mount
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const loc = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          setUserLocation(loc);
        },
        (error) => {
          console.warn('Geolocation error:', error);
        }
      );
    }
  }, []);

  // Load Risk Assessment
  useEffect(() => {
    setRiskResult(db.getRiskAssessment());
  }, [riskOpen]); // Reload when modal closes/changes

  // Restore chat session on mount
  useEffect(() => {
    const restoreSession = () => {
        const reqs = db.getSupportRequests();
        const active = reqs
            .filter((r: any) => r.status !== 'closed')
            .sort((a: any, b: any) => b.id - a.id)[0];
        
        if (active) {
            setCurrentId(active.id);
            setChatMessages(active.messages as ChatMessage[]);
        }
    };
    restoreSession();
  }, []);

  const setCurrentId = (id: number) => {
      setCurrentRequestId(id);
      currentRequestIdRef.current = id;
  };

  useEffect(() => {
      currentRequestIdRef.current = currentRequestId;
  }, [currentRequestId]);

  useEffect(() => {
    let interval: any;
    if (chatOpen && currentRequestId) {
        const loadMessages = () => {
             const reqs = db.getSupportRequests();
             const req = reqs.find((r: any) => r.id === currentRequestId);
             if (req) {
                 setChatMessages(req.messages as ChatMessage[]);
             }
        };
        loadMessages();
        interval = setInterval(loadMessages, 2000);
    }
    return () => clearInterval(interval);
  }, [chatOpen, currentRequestId]);

  useEffect(() => {
    if (chatOpen && chatEndRef.current) {
        chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages, chatOpen]);

  // Alert Styles Helper
  const getAlertStyles = (level: string) => {
    switch(level) {
      case 'critical':
        return {
          bg: '#fee2e2',
          border: '#ef4444',
          text: '#ef4444',
          icon: <AlertTriangle className="text-red-500 animate-pulse" />
        };
      case 'warning':
        return {
          bg: '#ffedd5',
          border: '#f97316',
          text: '#ea580c',
          icon: <AlertTriangle className="text-orange-600" />
        };
      case 'info':
      default:
        return {
          bg: '#eff6ff',
          border: '#3b82f6',
          text: '#2563eb',
          icon: <Info className="text-blue-600" />
        };
    }
  };

  const getRiskDisplay = (score: number) => {
      if (score >= 80) return { label: 'ایمن', color: '#22c55e', bg: '#f0fdf4', width: '90%' };
      if (score >= 50) return { label: 'نیاز به توجه', color: '#f97316', bg: '#fff7ed', width: '60%' };
      return { label: 'خطرناک', color: '#ef4444', bg: '#fef2f2', width: '30%' };
  };

  const handleCloseReport = () => setReportOpen(false);

  const handleReportSubmit = (data: { type: string; description: string; lat: number; lng: number }) => {
    if (onReportIncident) {
      onReportIncident(data);
    }
    handleCloseReport();
    setDrawerOpen(true);
    setSnackbarMessage('گزارش شما با موفقیت ثبت شد.');
    setSnackbarSeverity('success');
    setSnackbarOpen(true);
  };

  const handleSafeSubmit = () => {
    setSafeLoading(true);
    if ('geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                if (onSafeClick) {
                    onSafeClick({ 
                        lat: latitude, 
                        lng: longitude, 
                        name: safeName || 'شهروند' 
                    });
                }
                setSafeLoading(false);
                setSafeDialogOpen(false);
                setSafeName('');
                setSnackbarMessage('وضعیت سلامت شما با موفقیت ثبت شد.');
                setSnackbarSeverity('success');
                setSnackbarOpen(true);
            },
            (error) => {
                console.warn("Location error", error);
                setSafeLoading(false);
                setSnackbarMessage('خطا در دریافت موقعیت مکانی. لطفا GPS را روشن کنید.');
                setSnackbarSeverity('error');
                setSnackbarOpen(true);
            },
            { timeout: 10000 }
        )
    } else {
        setSafeLoading(false);
        setSnackbarMessage('مرورگر شما از موقعیت مکانی پشتیبانی نمی‌کند.');
        setSnackbarSeverity('error');
        setSnackbarOpen(true);
    }
  };

  // --- SOS Logic ---
  const handleSOS = () => {
      setChatOpen(true);
      
      const performSOS = (lat?: number, lng?: number) => {
         const activeId = currentRequestIdRef.current;

         if (activeId) {
             db.addSupportMessage(activeId, { sender: 'user', text: '🚨 درخواست کمک اضطراری (SOS)' });
             const reqs = db.getSupportRequests();
             const req = reqs.find((r: any) => r.id === activeId);
             if (req) setChatMessages(req.messages as ChatMessage[]);
         } else {
             const req = db.createSupportRequest({
                 user: safeName || 'شهروند',
                 lat: lat,
                 lng: lng,
                 message: '🚨 درخواست کمک اضطراری (SOS)'
             });
             setCurrentId(req.id);
             setChatMessages(req.messages as ChatMessage[]);
         }

         if (lat && lng && onReportIncident) {
             onReportIncident({
                 type: 'درخواست کمک اضطراری (SOS)',
                 description: 'درخواست فوری کمک از طریق چت',
                 lat: lat,
                 lng: lng
             });
         }
      };

      if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition((position) => {
              const { latitude, longitude } = position.coords;
              performSOS(latitude, longitude);
          }, (err) => {
              performSOS();
          });
      } else {
          performSOS();
      }
  };

  const handleSendMessage = () => {
      if (!messageInput.trim()) return;

      if (currentRequestId) {
          db.addSupportMessage(currentRequestId, { sender: 'user', text: messageInput });
          const reqs = db.getSupportRequests();
          const req = reqs.find((r: any) => r.id === currentRequestId);
          if (req) setChatMessages(req.messages as ChatMessage[]);
      } else {
          const req = db.createSupportRequest({
              user: safeName || 'شهروند',
              message: messageInput
          });
          setCurrentId(req.id);
          setChatMessages(req.messages as ChatMessage[]);
      }
      
      setMessageInput('');
  };

  const calculateRoute = async (start: {lat: number, lng: number}, end: {lat: number, lng: number}) => {
    setRouteInfo(null); 
    try {
        const url = `https://router.project-osrm.org/route/v1/driving/${start.lng},${start.lat};${end.lng},${end.lat}?overview=full&geometries=geojson`;
        const response = await axios.get(url);
        
        if (response.data.routes && response.data.routes.length > 0) {
           const route = response.data.routes[0];
           const coords = route.geometry.coordinates;
           const latLngs = coords.map((c: number[]) => [c[1], c[0]] as [number, number]);
           setRoutePath(latLngs);
           setRouteInfo({
             distance: route.distance,
             duration: route.duration
           });
        } else {
           setRoutePath([[start.lat, start.lng], [end.lat, end.lng]]);
           const dist = L.latLng(start.lat, start.lng).distanceTo(L.latLng(end.lat, end.lng));
           setRouteInfo({ distance: dist, duration: dist / 13 });
        }
    } catch (err) {
         setRoutePath([[start.lat, start.lng], [end.lat, end.lng]]);
         const dist = L.latLng(start.lat, start.lng).distanceTo(L.latLng(end.lat, end.lng));
         setRouteInfo({ distance: dist, duration: dist / 13 });
    }
  };

  const handleShelterClick = (shelter: Shelter) => {
      setTargetIncident(null);
      setTargetShelter(shelter);
      setIsNavigating(false);
      setRoutePath(null);
      setRouteInfo(null);
      setMapCenter({ lat: shelter.lat, lng: shelter.lng });
      setMapZoom(16);
  };

  const handleIncidentSelect = (incident: Incident) => {
      setTargetShelter(null);
      setTargetIncident(incident);
      setIsNavigating(false);
      setRoutePath(null);
      setRouteInfo(null);
      setMapCenter({ lat: incident.lat, lng: incident.lng });
      setMapZoom(16);
  };

  const handleViewOnMap = (lat: number, lng: number, itemType: 'shelter' | 'incident', item: any) => {
     setShowMap(true);
     setMapCenter({ lat, lng });
     setMapZoom(16);
     if (itemType === 'shelter') {
         handleShelterClick(item);
     } else {
         handleIncidentSelect(item);
     }
  };

  const handleStartNavigation = () => {
      const target = targetShelter || targetIncident;
      if (!target) return;
      
      if (!userLocation) {
          setSnackbarMessage('برای مسیریابی، دسترسی به موقعیت مکانی لازم است.');
          setSnackbarSeverity('error');
          setSnackbarOpen(true);
          return;
      }
      
      setIsNavigating(true);
      calculateRoute(userLocation, target);
  };

  const handleLocateMe = () => {
    if (userLocation) {
      setMapCenter(userLocation);
      setMapZoom(15);
    } else {
      setSnackbarMessage('در حال دریافت موقعیت مکانی...');
      setSnackbarSeverity('info');
      setSnackbarOpen(true);
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const loc = { lat: position.coords.latitude, lng: position.coords.longitude };
          setUserLocation(loc);
          setMapCenter(loc);
          setMapZoom(15);
        },
        () => {
           setSnackbarMessage('دسترسی به موقعیت مکانی امکان‌پذیر نیست.');
           setSnackbarSeverity('error');
           setSnackbarOpen(true);
        }
      );
    }
  };

  const openExternalMap = (app: 'google' | 'neshan' | 'balad') => {
      const target = targetShelter || targetIncident;
      if (!target) return;
      const { lat, lng } = target;
      let url = '';
      switch(app) {
          case 'google': url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`; break;
          case 'neshan': url = `https://neshan.org/maps/route?d_lat=${lat}&d_lng=${lng}&mode=d`; break;
          case 'balad': url = `https://balad.ir/route?dest_lat=${lat}&dest_lng=${lng}&mode=driving`; break;
      }
      window.open(url, '_blank');
  };

  const handleCloseSnackbar = () => setSnackbarOpen(false);
  const activeTarget = targetShelter || targetIncident;

  // Render List View
  const renderListView = () => (
        <Box sx={{ position: 'relative', height: '100%', width: '100%', display: 'flex', flexDirection: 'column', bgcolor: '#f8fafc', overflowY: 'auto', p: 0, pb: 10 }}>
            
            {/* 1. Alerts Section (Dynamic) */}
            {alerts.length > 0 && (
                <Box px={2} pt={2} pb={1}>
                    <Stack spacing={1}>
                        {alerts.map(alert => {
                            const style = getAlertStyles(alert.level);
                            return (
                                <Fade in={true} key={alert.id}>
                                    <Paper 
                                        elevation={0}
                                        sx={{ 
                                            p: 2, 
                                            bgcolor: style.bg, 
                                            border: `1px solid ${style.border}`,
                                            borderRadius: 2,
                                            display: 'flex',
                                            gap: 2,
                                            alignItems: 'flex-start',
                                            direction: 'rtl',
                                            animation: alert.level === 'critical' ? 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite' : 'none',
                                            '@keyframes pulse': {
                                                '0%, 100%': { opacity: 1 },
                                                '50%': { opacity: 0.9, transform: 'scale(0.99)' },
                                            }
                                        }}
                                    >
                                        <Box mt={0.5}>{style.icon}</Box>
                                        <Box>
                                            <Typography variant="subtitle2" fontWeight="bold" sx={{ fontFamily: 'Vazirmatn', color: style.text }}>
                                                {alert.message}
                                            </Typography>
                                            <Box display="flex" gap={1} mt={1} alignItems="center">
                                                <Chip label={alert.target === 'region' ? (alert.region ? `منطقه ${alert.region}` : 'منطقه‌ای') : 'عمومی'} size="small" sx={{ fontFamily: 'Vazirmatn', height: 20, fontSize: '0.7rem' }} />
                                                <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'Vazirmatn' }}>
                                                    {new Date(alert.createdAt).toLocaleTimeString('fa-IR')}
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </Paper>
                                </Fade>
                            )
                        })}
                    </Stack>
                </Box>
            )}

            {/* 2. Quick Services Grid */}
            <Box p={2}>
                <Typography variant="subtitle2" color="text.secondary" mb={1.5} sx={{ fontFamily: 'Vazirmatn' }}>خدمات سریع</Typography>
                <Grid container spacing={2}>
                    <Grid size={{ xs: 3 }}>
                        <Paper 
                            elevation={0}
                            onClick={() => setSurvivalOpen(true)}
                            sx={{ 
                                p: 1.5, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1, 
                                borderRadius: 3, cursor: 'pointer', bgcolor: 'white', border: '1px solid #e2e8f0',
                                transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-2px)' }
                            }}
                        >
                            <Box p={1.5} bgcolor="#e0f2fe" borderRadius="50%" color="#0284c7"><Backpack size={20} /></Box>
                            <Typography variant="caption" fontFamily="Vazirmatn" fontWeight="bold" textAlign="center">کوله نجات</Typography>
                        </Paper>
                    </Grid>
                    <Grid size={{ xs: 3 }}>
                        <Paper 
                            elevation={0}
                            onClick={() => setEduOpen(true)}
                            sx={{ 
                                p: 1.5, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1, 
                                borderRadius: 3, cursor: 'pointer', bgcolor: 'white', border: '1px solid #e2e8f0',
                                transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-2px)' }
                            }}
                        >
                            <Box p={1.5} bgcolor="#f0fdf4" borderRadius="50%" color="#16a34a"><BookOpen size={20} /></Box>
                            <Typography variant="caption" fontFamily="Vazirmatn" fontWeight="bold" textAlign="center">آموزش</Typography>
                        </Paper>
                    </Grid>
                    <Grid size={{ xs: 3 }}>
                        <Paper 
                            elevation={0}
                            onClick={() => setReportOpen(true)}
                            sx={{ 
                                p: 1.5, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1, 
                                borderRadius: 3, cursor: 'pointer', bgcolor: 'white', border: '1px solid #e2e8f0',
                                transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-2px)' }
                            }}
                        >
                            <Box p={1.5} bgcolor="#fef2f2" borderRadius="50%" color="#dc2626"><ClipboardList size={20} /></Box>
                            <Typography variant="caption" fontFamily="Vazirmatn" fontWeight="bold" textAlign="center">ثبت گزارش</Typography>
                        </Paper>
                    </Grid>
                    <Grid size={{ xs: 3 }}>
                        <Paper 
                            elevation={0}
                            onClick={() => setRiskOpen(true)}
                            sx={{ 
                                p: 1.5, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1, 
                                borderRadius: 3, cursor: 'pointer', bgcolor: 'white', border: '1px solid #e2e8f0',
                                transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-2px)' }
                            }}
                        >
                            <Box p={1.5} bgcolor="#fff7ed" borderRadius="50%" color="#ea580c"><Activity size={20} /></Box>
                            <Typography variant="caption" fontFamily="Vazirmatn" fontWeight="bold" textAlign="center">ایمنی</Typography>
                        </Paper>
                    </Grid>
                </Grid>
            </Box>

            {/* 3. Building Health / Risk Assessment Result */}
            <Box px={2} mb={3}>
                <Typography variant="subtitle2" color="text.secondary" mb={1.5} sx={{ fontFamily: 'Vazirmatn' }}>وضعیت ایمنی ساختمان شما</Typography>
                {riskResult ? (
                    <Paper 
                        elevation={0}
                        onClick={() => setRiskOpen(true)}
                        sx={{ 
                            p: 2, 
                            borderRadius: 3,
                            cursor: 'pointer',
                            background: `linear-gradient(135deg, ${getRiskDisplay(riskResult.score).bg} 0%, #ffffff 100%)`,
                            border: `1px solid ${getRiskDisplay(riskResult.score).color}40`,
                            position: 'relative',
                            overflow: 'hidden'
                        }}
                    >
                        <Box display="flex" justifyContent="space-between" alignItems="center">
                            <Box>
                                <Typography variant="h6" fontFamily="Vazirmatn" fontWeight="bold" sx={{ color: getRiskDisplay(riskResult.score).color }}>
                                    {getRiskDisplay(riskResult.score).label}
                                </Typography>
                                <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn">
                                    آخرین بررسی: {new Date(riskResult.date).toLocaleDateString('fa-IR')}
                                </Typography>
                            </Box>
                            <Box 
                                width={50} height={50} borderRadius="50%" 
                                display="flex" alignItems="center" justifyContent="center"
                                sx={{ bgcolor: getRiskDisplay(riskResult.score).color, color: 'white', fontWeight: 'bold' }}
                            >
                                {toPersianDigits(riskResult.score)}
                            </Box>
                        </Box>
                        <Box mt={2} bgcolor="rgba(0,0,0,0.05)" borderRadius={1} height={6} width="100%">
                            <Box 
                                height="100%" 
                                borderRadius={1} 
                                sx={{ width: `${riskResult.score}%`, bgcolor: getRiskDisplay(riskResult.score).color, transition: 'width 1s' }} 
                            />
                        </Box>
                    </Paper>
                ) : (
                    <Paper 
                        elevation={0}
                        onClick={() => setRiskOpen(true)}
                        sx={{ 
                            p: 2, borderRadius: 3, cursor: 'pointer', bgcolor: 'white', border: '1px dashed #94a3b8',
                            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 2
                        }}
                    >
                        <Home className="text-gray-400" />
                        <Typography variant="body2" color="text.secondary" fontFamily="Vazirmatn">
                            هنوز ارزیابی ایمنی انجام نداده‌اید. برای شروع کلیک کنید.
                        </Typography>
                    </Paper>
                )}
            </Box>

            {/* 4. Recent Incidents */}
            <Box px={2}>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={1.5}>
                    <Typography variant="subtitle2" color="text.secondary" sx={{ fontFamily: 'Vazirmatn' }}>آخرین اتفاقات شهر</Typography>
                    <Button size="small" onClick={() => setDrawerOpen(true)} endIcon={<ChevronRight size={14} />} sx={{ fontFamily: 'Vazirmatn', fontSize: '0.75rem' }}>مشاهده همه</Button>
                </Box>
                <Stack spacing={1.5}>
                    {incidents.slice(0, 5).map(incident => (
                        <Card key={incident.id} elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: 2 }}>
                             <CardActionArea onClick={() => handleViewOnMap(incident.lat, incident.lng, 'incident', incident)} sx={{ p: 1.5 }}>
                                 <Box display="flex" justifyContent="space-between" alignItems="start">
                                    <Box display="flex" gap={1.5}>
                                        <Box mt={0.5} color={incident.type === 'آتش‌سوزی' ? '#ef4444' : '#64748b'}>
                                            <MapPin size={18} />
                                        </Box>
                                        <Box>
                                            <Typography variant="body2" fontWeight="bold" sx={{ fontFamily: 'Vazirmatn' }}>{incident.title}</Typography>
                                            <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'Vazirmatn', display: 'block', mt: 0.5 }}>
                                                {incident.address || 'آدرس نامشخص'}
                                            </Typography>
                                        </Box>
                                    </Box>
                                    <Chip 
                                        label={incident.type} 
                                        size="small" 
                                        sx={{ 
                                            fontFamily: 'Vazirmatn', height: 20, fontSize: '0.65rem',
                                            bgcolor: incident.type === 'آتش‌سوزی' ? '#fef2f2' : '#f1f5f9',
                                            color: incident.type === 'آتش‌سوزی' ? '#dc2626' : '#475569'
                                        }} 
                                    />
                                 </Box>
                             </CardActionArea>
                        </Card>
                    ))}
                    {incidents.length === 0 && (
                        <Typography variant="body2" color="text.secondary" textAlign="center" sx={{ fontFamily: 'Vazirmatn', py: 4 }}>
                            گزارشی ثبت نشده است.
                        </Typography>
                    )}
                </Stack>
            </Box>
        </Box>
  );

  // Render Map View
  const renderMapView = () => (
    <Box sx={{ width: '100%', height: '100%', position: 'relative', bgcolor: '#e2e8f0' }}>
       <MapContainer 
          center={mapCenter || [34.64, 50.87]} 
          zoom={mapZoom} 
          style={{ width: '100%', height: '100%' }}
          zoomControl={false}
       >
          <TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          <MapController center={mapCenter} zoom={mapZoom} />
          {userLocation && <Marker position={[userLocation.lat, userLocation.lng]} icon={blueIcon}><Popup className="vazir-font">موقعیت شما</Popup></Marker>}
          {incidents.map(inc => (
             <Marker key={inc.id} position={[inc.lat, inc.lng]} icon={redIcon} eventHandlers={{ click: () => handleIncidentSelect(inc) }}>
                <Popup className="vazir-font">{inc.title}</Popup>
             </Marker>
          ))}
          {shelters.map(shelter => (
             <CircleMarker key={shelter.id} center={[shelter.lat, shelter.lng]} radius={12} pathOptions={{ color: 'white', fillColor: shelter.status === 'full' ? '#ef4444' : '#22c55e', fillOpacity: 1, weight: 2 }} eventHandlers={{ click: () => handleShelterClick(shelter) }}>
                <Popup className="vazir-font">{shelter.name}</Popup>
             </CircleMarker>
          ))}
          {routePath && <Polyline positions={routePath} color="blue" weight={4} />}
       </MapContainer>
       <Box position="absolute" top={16} right={16} left={16} zIndex={1000} display="flex" justifyContent="space-between" sx={{ pointerEvents: 'none' }}>
           <Box sx={{ pointerEvents: 'auto' }}>
              <Fab size="small" onClick={() => setShowMap(false)} sx={{ bgcolor: 'white' }}><LayoutList size={20} /></Fab>
           </Box>
           <Box sx={{ pointerEvents: 'auto', display: 'flex', gap: 1 }}>
              <Fab size="small" onClick={handleLocateMe} sx={{ bgcolor: 'white' }}><Crosshair size={20} /></Fab>
           </Box>
       </Box>
       {activeTarget && (
          <Paper 
             sx={{ 
                position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 1000, p: 2, pb: 10,
                borderTopLeftRadius: 16, borderTopRightRadius: 16, maxHeight: '50vh', overflowY: 'auto'
             }}
             elevation={4}
          >
             <Box display="flex" justifyContent="space-between" alignItems="start" mb={2}>
                 <Box>
                    <Typography variant="h6" fontWeight="bold" fontFamily="Vazirmatn">{'name' in activeTarget ? activeTarget.name : activeTarget.title}</Typography>
                    <Typography variant="body2" color="text.secondary" fontFamily="Vazirmatn">{'address' in activeTarget ? activeTarget.address : (activeTarget as Shelter).capacity + ' نفر ظرفیت'}</Typography>
                 </Box>
                 <IconButton onClick={() => { setTargetShelter(null); setTargetIncident(null); }} size="small"><X /></IconButton>
             </Box>
             {routeInfo && (
                <Box mb={2} display="flex" gap={2} bgcolor="#f8fafc" p={1.5} borderRadius={2}>
                    <Box display="flex" alignItems="center" gap={0.5}>
                        <Clock size={16} className="text-blue-600" />
                        <Typography variant="body2" fontFamily="Vazirmatn" fontWeight="bold">{formatDuration(routeInfo.duration)}</Typography>
                    </Box>
                    <Box display="flex" alignItems="center" gap={0.5}>
                        <Navigation size={16} className="text-blue-600" />
                        <Typography variant="body2" fontFamily="Vazirmatn" fontWeight="bold">{formatDistance(routeInfo.distance)}</Typography>
                    </Box>
                </Box>
             )}
             <Box display="flex" gap={2}>
                 {!isNavigating ? (
                    <Button variant="contained" fullWidth startIcon={<Navigation />} onClick={handleStartNavigation} sx={{ fontFamily: 'Vazirmatn', py: 1.5 }}>مسیریابی</Button>
                 ) : (
                    <Button variant="outlined" color="error" fullWidth startIcon={<StopCircle />} onClick={() => setIsNavigating(false)} sx={{ fontFamily: 'Vazirmatn', py: 1.5 }}>لغو مسیریابی</Button>
                 )}
                 <Button variant="outlined" sx={{ minWidth: 50 }} onClick={() => openExternalMap('google')}><MapPin /></Button>
             </Box>
          </Paper>
       )}
    </Box>
  );

  return (
    <Box sx={{ height: '100%', width: '100%', position: 'relative', overflow: 'hidden' }}>
        {showMap ? renderMapView() : renderListView()}

        {/* Bottom Fixed Dock - Always Visible */}
        <Paper 
            elevation={3} 
            sx={{ 
                position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 1100, 
                display: 'flex', justifyContent: 'space-around', alignItems: 'center', p: 1.5,
                borderTopLeftRadius: 16, borderTopRightRadius: 16, borderTop: '1px solid #e2e8f0'
            }}
        >
            <Button 
                onClick={() => { setShowMap(true); handleLocateMe(); }}
                sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, color: showMap ? 'primary.main' : 'text.secondary', minWidth: 80 }}
            >
                <MapIcon size={24} />
                <Typography variant="caption" fontFamily="Vazirmatn" fontSize="0.7rem">نقشه / مسیر</Typography>
            </Button>
            
            <Button 
                onClick={() => setSafeDialogOpen(true)}
                sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, color: 'text.secondary', minWidth: 80 }}
            >
                <ShieldCheck size={24} className="text-green-600" />
                <Typography variant="caption" fontFamily="Vazirmatn" fontSize="0.7rem">اعلام امنیت</Typography>
            </Button>
            
            <Button 
                onClick={handleSOS}
                variant="contained"
                color="error"
                sx={{ 
                    borderRadius: '50%', minWidth: 56, width: 56, height: 56, 
                    boxShadow: '0 4px 14px rgba(239, 68, 68, 0.4)', 
                    position: 'relative', top: -20, border: '4px solid white'
                }}
            >
                <Typography fontWeight="bold" fontSize="0.9rem">SOS</Typography>
            </Button>
        </Paper>

        <Dialog open={safeDialogOpen} onClose={() => !safeLoading && setSafeDialogOpen(false)} fullWidth maxWidth="xs" dir="rtl">
            <Box p={3} textAlign="center">
                <Box mx="auto" mb={2} p={2} bgcolor="#dcfce7" borderRadius="50%" width="fit-content" color="#166534"><ShieldCheck size={48} /></Box>
                <Typography variant="h6" fontWeight="bold" sx={{ fontFamily: 'Vazirmatn' }} gutterBottom>ثبت وضعیت سلامت</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ fontFamily: 'Vazirmatn', mb: 3 }}>با اعلام وضعیت خود، به مدیریت بهتر بحران کمک می‌کنید.</Typography>
                <TextField fullWidth variant="outlined" label="نام شما (اختیاری)" value={safeName} onChange={(e) => setSafeName(e.target.value)} disabled={safeLoading} placeholder="مثال: علی محمدی" sx={{ mb: 3, '& .MuiInputBase-root': { fontFamily: 'Vazirmatn' }, '& .MuiInputLabel-root': { fontFamily: 'Vazirmatn' } }} />
                <Button variant="contained" color="success" fullWidth size="large" onClick={handleSafeSubmit} disabled={safeLoading} sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold', py: 1.5 }}>
                    {safeLoading ? <CircularProgress size={24} color="inherit" /> : 'من امن هستم'}
                </Button>
            </Box>
        </Dialog>
        <Dialog open={reportOpen} onClose={handleCloseReport} fullWidth maxWidth="sm">
            <ReportIncidentForm onSubmit={handleReportSubmit} onCancel={handleCloseReport} />
        </Dialog>

        {/* Feature Modals */}
        <Dialog open={survivalOpen} onClose={() => setSurvivalOpen(false)} fullWidth maxWidth="sm" dir="rtl" TransitionComponent={Fade} transitionDuration={400}>
             <Box p={1}><SurvivalKit onClose={() => setSurvivalOpen(false)} /></Box>
        </Dialog>
        
        <Dialog open={riskOpen} onClose={() => setRiskOpen(false)} fullWidth maxWidth="sm" dir="rtl" TransitionComponent={Fade} transitionDuration={400}>
             <Box p={1}>
                <RiskAssessment 
                    onClose={() => setRiskOpen(false)} 
                    onUpdate={() => setRiskResult(db.getRiskAssessment())} 
                />
             </Box>
        </Dialog>
        
        <Dialog open={eduOpen} onClose={() => setEduOpen(false)} fullWidth maxWidth="sm" dir="rtl" TransitionComponent={Fade} transitionDuration={400}>
             <Box p={2}><EducationHub onClose={() => setEduOpen(false)} /></Box>
        </Dialog>

        <Drawer anchor="bottom" open={chatOpen} onClose={() => setChatOpen(false)} PaperProps={{ sx: { height: '80vh', borderTopLeftRadius: 16, borderTopRightRadius: 16, maxWidth: 600, mx: 'auto' } }}>
            <Box display="flex" flexDirection="column" height="100%" dir="rtl">
                <Box p={2} borderBottom={1} borderColor="divider" display="flex" justifyContent="space-between" alignItems="center" bgcolor="#f8fafc">
                    <Box display="flex" alignItems="center" gap={1}>
                        <Avatar sx={{ bgcolor: '#ef4444' }}><Headphones /></Avatar>
                        <Box>
                            <Typography variant="subtitle1" fontWeight="bold" sx={{ fontFamily: 'Vazirmatn' }}>پشتیبانی اضطراری</Typography>
                            <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'Vazirmatn' }}>متصل به مرکز امداد</Typography>
                        </Box>
                    </Box>
                    <IconButton onClick={() => setChatOpen(false)}><X /></IconButton>
                </Box>
                <Box flexGrow={1} overflow="auto" p={2} display="flex" flexDirection="column" gap={2}>
                    {chatMessages.map((msg) => (
                        <Box key={msg.id} display="flex" justifyContent={msg.sender === 'user' ? 'flex-end' : (msg.sender === 'system' ? 'center' : 'flex-start')}>
                            <Paper elevation={0} sx={{ p: 1.5, maxWidth: '80%', borderRadius: 2, bgcolor: msg.sender === 'user' ? '#3b82f6' : (msg.sender === 'system' ? '#f1f5f9' : '#e2e8f0'), color: msg.sender === 'user' ? 'white' : 'text.primary', border: msg.sender === 'system' ? '1px dashed #94a3b8' : 'none' }}>
                                <Typography variant="body2" sx={{ fontFamily: 'Vazirmatn', whiteSpace: 'pre-line' }}>{msg.text}</Typography>
                                <Typography variant="caption" display="block" textAlign={msg.sender === 'user' ? 'left' : 'right'} sx={{ opacity: 0.7, mt: 0.5, fontSize: '0.65rem' }}>{msg.time}</Typography>
                            </Paper>
                        </Box>
                    ))}
                    <div ref={chatEndRef} />
                </Box>
                <Box p={2} borderTop={1} borderColor="divider" display="flex" gap={1}>
                    <TextField fullWidth size="small" placeholder="پیام خود را بنویسید..." value={messageInput} onChange={(e) => setMessageInput(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()} sx={{ '& .MuiInputBase-root': { fontFamily: 'Vazirmatn' } }} />
                    <IconButton color="primary" onClick={handleSendMessage} disabled={!messageInput.trim()}><Send /></IconButton>
                </Box>
            </Box>
        </Drawer>
        <Drawer anchor="right" open={drawerOpen} onClose={() => setDrawerOpen(false)} PaperProps={{ sx: { width: '85%', maxWidth: 360, borderTopLeftRadius: 16, borderBottomLeftRadius: 16 } }}>
            <Box sx={{ p: 2, height: '100%', display: 'flex', flexDirection: 'column', direction: 'rtl' }}>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                        <Typography variant="h6" fontWeight="bold" sx={{ fontFamily: 'Vazirmatn' }}>پیگیری گزارش‌ها</Typography>
                        <IconButton onClick={() => setDrawerOpen(false)} size="small"><X size={20} /></IconButton>
                </Box>
                <Divider sx={{ mb: 2 }} />
                <List sx={{ overflowY: 'auto', flexGrow: 1 }}>
                    {incidents.filter(inc => inc.reporter === 'شهروند').map((report) => (
                        <Paper key={report.id} elevation={0} sx={{ mb: 2, border: '1px solid #e2e8f0', borderRadius: 2 }}>
                            <ListItem sx={{ flexDirection: 'column', alignItems: 'flex-start', p: 2 }}>
                                <Box display="flex" justifyContent="space-between" width="100%" mb={1}>
                                    <Typography variant="subtitle1" fontWeight="bold" sx={{ fontFamily: 'Vazirmatn' }}>{report.type}</Typography>
                                    <Chip label={report.status} size="small" color={report.status === 'جدید' ? 'error' : (report.status === 'حل شده' ? 'success' : 'warning')} sx={{ fontFamily: 'Vazirmatn' }} />
                                </Box>
                            </ListItem>
                        </Paper>
                    ))}
                </List>
            </Box>
        </Drawer>
        <Snackbar open={snackbarOpen} autoHideDuration={6000} onClose={handleCloseSnackbar} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }} sx={{ bottom: 80 }}>
            <Alert onClose={handleCloseSnackbar} severity={snackbarSeverity} sx={{ width: '100%', fontFamily: 'Vazirmatn' }} variant="filled">{snackbarMessage}</Alert>
        </Snackbar>
    </Box>
  );
};

export default CitizenHome;
