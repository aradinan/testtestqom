
import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Paper, 
  Typography, 
  Grid, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Chip, 
  Button, 
  Select, 
  MenuItem, 
  FormControl, 
  InputLabel,
  Snackbar,
  Alert,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField
} from '@mui/material';
import { 
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
import { Truck, CheckCircle, Filter, Archive, FileText, XCircle } from 'lucide-react';
import { db } from '../db';

// Helper for Persian Numbers
const toPersianDigits = (num: string | number) => {
  if (num === undefined || num === null) return '';
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, x => farsiDigits[parseInt(x)]);
};

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF'];
const RESOURCE_COLORS = {
  Available: '#22c55e', // Green
  Dispatched: '#f97316', // Orange
  Maintenance: '#ef4444' // Red
};

const AnalyticsDashboard = () => {
  const [incidents, setIncidents] = useState<any[]>([]);
  const [resources, setResources] = useState<any[]>([]);
  const [vulnPoints, setVulnPoints] = useState<any[]>([]);
  const [vulnFilter, setVulnFilter] = useState('all');
  
  // Stats
  const [typeData, setTypeData] = useState<any[]>([]);
  const [regionData, setRegionData] = useState<any[]>([]);
  const [resourceStats, setResourceStats] = useState<any[]>([]);
  
  // Selection State for Dispatch
  const [selectedResource, setSelectedResource] = useState<Record<string, string>>({});
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' as 'success' | 'info' | 'error' });

  // Archive Dialog State
  const [archiveOpen, setArchiveOpen] = useState(false);
  const [closingIncidentId, setClosingIncidentId] = useState<number | null>(null);
  const [closingReport, setClosingReport] = useState('');

  const loadData = () => {
    const iData = db.getIncidents();
    const vData = db.getVulnerabilityPoints();
    const rData = db.getResources();
    
    setIncidents(iData);
    setVulnPoints(vData);
    setResources(rData);

    // Process Type Data
    const types: Record<string, number> = {};
    iData.forEach((i: any) => {
        types[i.type] = (types[i.type] || 0) + 1;
    });
    setTypeData(Object.keys(types).map(key => ({ name: key, value: types[key] })));

    // Process Region Data
    const regions: Record<string, number> = {};
    iData.forEach((i: any) => {
        const reg = i.region || 'نامشخص';
        regions[reg] = (regions[reg] || 0) + 1;
    });
    setRegionData(Object.keys(regions).map(key => ({ name: `منطقه ${key}`, value: regions[key] })));

    // Process Resource Stats
    const rStats = { Available: 0, Dispatched: 0, Maintenance: 0 };
    rData.forEach((r: any) => {
        const status = r.status as keyof typeof rStats;
        if (rStats[status] !== undefined) rStats[status]++;
    });
    setResourceStats([
        { name: 'آماده', value: rStats.Available, color: RESOURCE_COLORS.Available },
        { name: 'در ماموریت', value: rStats.Dispatched, color: RESOURCE_COLORS.Dispatched },
        { name: 'خراب/تعمیر', value: rStats.Maintenance, color: RESOURCE_COLORS.Maintenance },
    ]);
  };

  useEffect(() => {
    loadData();
    // Refresh every 5 seconds to keep synced
    const interval = setInterval(loadData, 5000);
    return () => clearInterval(interval);
  }, []);

  const getRiskColor = (score: number) => {
      // Lower score = Higher Risk
      if (score < 30) return '#ef4444'; // Red
      if (score < 60) return '#f97316'; // Orange
      return '#eab308'; // Yellow
  };

  // Helper to check if an incident has resources assigned
  const getAssignedResources = (incidentId: number) => {
      return resources.filter(r => r.incidentId === incidentId);
  };

  const handleDispatch = (incidentId: number) => {
      const resourceIdStr = selectedResource[incidentId];
      if (!resourceIdStr) {
          setSnackbar({ open: true, message: 'لطفا یک منبع را انتخاب کنید', severity: 'error' });
          return;
      }
      const resourceId = parseInt(resourceIdStr);
      
      db.assignResource(resourceId, incidentId);
      
      setSnackbar({ open: true, message: 'منبع با موفقیت اعزام شد', severity: 'success' });
      setSelectedResource(prev => ({ ...prev, [incidentId]: '' }));
      loadData();
  };

  const handleRelease = (resourceId: number) => {
      db.releaseResource(resourceId);
      loadData();
      setSnackbar({ open: true, message: 'منبع آزاد شد و به ایستگاه بازگشت', severity: 'info' });
  };

  const handleOpenArchive = (id: number) => {
      setClosingIncidentId(id);
      setClosingReport('');
      setArchiveOpen(true);
  };

  const handleConfirmArchive = () => {
      if (closingIncidentId) {
          // 1. Release all resources
          const assigned = getAssignedResources(closingIncidentId);
          assigned.forEach(r => db.releaseResource(r.id));
          
          // 2. Close incident
          const incident = incidents.find(i => i.id === closingIncidentId);
          if (incident) {
              // We could store the closing report in a real backend, 
              // for now we just change status which is effectively archiving it from this view.
              db.saveIncident({ ...incident, status: 'حل شده' });
          }
          
          setSnackbar({ open: true, message: 'عملیات پایان یافت و بایگانی شد', severity: 'success' });
          setArchiveOpen(false);
          loadData();
      }
  };

  // Filter for Active Incidents
  // Criteria: 
  // 1. Not resolved (Active)
  // 2. AND (Is High Severity OR Has Resources Assigned)
  // This ensures we see critical items AND items we are currently working on.
  const activeOperations = incidents.filter(inc => {
      const isClosed = inc.status === 'حل شده';
      if (isClosed) return false;
      
      const assignedCount = getAssignedResources(inc.id).length;
      return inc.severity === 'زیاد' || assignedCount > 0;
  });

  const availableResources = resources.filter(r => r.status === 'Available');

  // Filter Vulnerability Points
  const uniqueVulnRegions = Array.from(new Set(vulnPoints.map(p => p.region))).filter(Boolean).sort();
  const filteredVulnPoints = vulnFilter === 'all' ? vulnPoints : vulnPoints.filter(p => p.region === vulnFilter);

  return (
    <Box>
        <Typography variant="h5" fontWeight="bold" fontFamily="Vazirmatn" mb={3} color="text.primary">
            تحلیل داده‌ها و عملیات
        </Typography>

        {/* Charts Section */}
        <Grid container spacing={3} mb={4}>
            {/* Incident Types Pie Chart */}
            <Grid size={{ xs: 12, md: 4 }}>
                <Paper sx={{ p: 3, height: 380, borderRadius: 2 }}>
                    <Typography variant="h6" fontFamily="Vazirmatn" mb={2}>توزیع انواع حوادث</Typography>
                    <ResponsiveContainer width="100%" height="90%">
                        <PieChart>
                            <Pie
                                data={typeData}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                outerRadius={80}
                                fill="#8884d8"
                                dataKey="value"
                                label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                                {typeData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip />
                        </PieChart>
                    </ResponsiveContainer>
                </Paper>
            </Grid>

            {/* Resource Utilization Chart */}
            <Grid size={{ xs: 12, md: 4 }}>
                <Paper sx={{ p: 3, height: 380, borderRadius: 2 }}>
                    <Typography variant="h6" fontFamily="Vazirmatn" mb={2}>وضعیت ناوگان و منابع</Typography>
                    <ResponsiveContainer width="100%" height="90%">
                        <PieChart>
                            <Pie
                                data={resourceStats}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={80}
                                paddingAngle={5}
                                dataKey="value"
                            >
                                {resourceStats.map((entry, index) => (
                                    <Cell key={`cell-res-${index}`} fill={entry.color} />
                                ))}
                            </Pie>
                            <Tooltip />
                            <Legend verticalAlign="bottom" height={36}/>
                        </PieChart>
                    </ResponsiveContainer>
                    <Box display="flex" justifyContent="center" mt={-20}>
                        <Typography variant="h4" fontWeight="bold" fontFamily="Vazirmatn">
                             {toPersianDigits(resources.length)}
                        </Typography>
                    </Box>
                    <Box display="flex" justifyContent="center">
                        <Typography variant="caption" color="text.secondary" fontFamily="Vazirmatn">کل منابع</Typography>
                    </Box>
                </Paper>
            </Grid>

            {/* Incidents by Region Bar Chart */}
            <Grid size={{ xs: 12, md: 4 }}>
                <Paper sx={{ p: 3, height: 380, borderRadius: 2 }}>
                    <Typography variant="h6" fontFamily="Vazirmatn" mb={2}>پراکندگی منطقه‌ای</Typography>
                    <ResponsiveContainer width="100%" height="90%">
                        <BarChart
                            data={regionData}
                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" fontFamily="Vazirmatn" angle={-45} textAnchor="end" height={60} />
                            <YAxis />
                            <Tooltip />
                            <Bar dataKey="value" name="تعداد حوادث" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </Paper>
            </Grid>
        </Grid>

        {/* Quick Dispatch Section */}
        <Typography variant="h5" fontWeight="bold" fontFamily="Vazirmatn" mb={2} mt={6} color="text.primary" display="flex" alignItems="center" gap={1}>
            <Truck className="text-blue-600" /> مدیریت عملیات و اعزام (حوادث بحرانی)
        </Typography>
        <Paper sx={{ mb: 4, overflow: 'hidden', borderRadius: 2 }}>
             <TableContainer>
                 <Table dir="rtl">
                     <TableHead sx={{ bgcolor: '#f1f5f9' }}>
                         <TableRow>
                             <TableCell sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>حادثه</TableCell>
                             <TableCell sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>اولویت</TableCell>
                             <TableCell sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>موقعیت</TableCell>
                             <TableCell sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>مدیریت منابع (آزادسازی)</TableCell>
                             <TableCell sx={{ fontFamily: 'Vazirmatn', fontWeight: 'bold' }}>اعزام جدید / بایگانی</TableCell>
                         </TableRow>
                     </TableHead>
                     <TableBody>
                         {activeOperations.length === 0 ? (
                             <TableRow>
                                 <TableCell colSpan={5} align="center" sx={{ py: 3, fontFamily: 'Vazirmatn', color: 'text.secondary' }}>
                                     <Box display="flex" alignItems="center" justifyContent="center" gap={1}>
                                         <CheckCircle className="text-green-500" />
                                         هیچ عملیات فعال یا بحرانی وجود ندارد.
                                     </Box>
                                 </TableCell>
                             </TableRow>
                         ) : (
                             activeOperations.map((inc) => {
                                 const assignedResources = getAssignedResources(inc.id);
                                 return (
                                     <TableRow key={inc.id} hover>
                                         <TableCell sx={{ fontFamily: 'Vazirmatn' }}>
                                             <Typography variant="subtitle2" fontWeight="bold">{inc.title}</Typography>
                                             <Typography variant="caption" color="text.secondary">{inc.type}</Typography>
                                         </TableCell>
                                         <TableCell>
                                             <Chip 
                                                label={inc.severity || 'معمولی'} 
                                                color={inc.severity === 'زیاد' ? 'error' : 'warning'}
                                                size="small"
                                                sx={{ fontFamily: 'Vazirmatn' }}
                                             />
                                         </TableCell>
                                         <TableCell sx={{ fontFamily: 'Vazirmatn' }}>
                                             {inc.region ? `منطقه ${toPersianDigits(inc.region)}` : 'نامشخص'}
                                             <br/>
                                             <Typography variant="caption" color="text.secondary">{inc.neighborhood}</Typography>
                                         </TableCell>
                                         <TableCell>
                                             <Box display="flex" flexWrap="wrap" gap={0.5}>
                                                {assignedResources.length === 0 ? (
                                                    <Typography variant="caption" color="text.disabled">بدون منبع</Typography>
                                                ) : (
                                                    assignedResources.map(res => (
                                                        <Chip 
                                                            key={res.id}
                                                            label={res.name}
                                                            onDelete={() => handleRelease(res.id)}
                                                            deleteIcon={
                                                                <span title="آزادسازی منبع" style={{ display: 'flex', alignItems: 'center' }}>
                                                                    <XCircle size={14} />
                                                                </span>
                                                            }
                                                            color="primary"
                                                            variant="outlined"
                                                            size="small"
                                                            sx={{ fontFamily: 'Vazirmatn' }}
                                                        />
                                                    ))
                                                )}
                                             </Box>
                                         </TableCell>
                                         <TableCell>
                                             <Box display="flex" gap={1} alignItems="center">
                                                 <FormControl size="small" sx={{ minWidth: 140 }}>
                                                     <InputLabel sx={{ fontFamily: 'Vazirmatn', fontSize: '0.8rem' }}>اعزام منبع جدید</InputLabel>
                                                     <Select
                                                         value={selectedResource[inc.id] || ''}
                                                         label="اعزام منبع جدید"
                                                         onChange={(e) => setSelectedResource({ ...selectedResource, [inc.id]: e.target.value })}
                                                         sx={{ fontFamily: 'Vazirmatn', height: 40 }}
                                                     >
                                                         {availableResources.length === 0 ? (
                                                             <MenuItem disabled value="" sx={{ fontFamily: 'Vazirmatn' }}>منبع آزاد موجود نیست</MenuItem>
                                                         ) : (
                                                             availableResources.map(res => (
                                                                 <MenuItem key={res.id} value={res.id} sx={{ fontFamily: 'Vazirmatn', display: 'flex', justifyContent: 'space-between' }}>
                                                                     <span>{res.name}</span>
                                                                     <Typography variant="caption" color="text.secondary" ml={1}>{res.type}</Typography>
                                                                 </MenuItem>
                                                             ))
                                                         )}
                                                     </Select>
                                                 </FormControl>
                                                 <IconButton 
                                                    color="primary" 
                                                    disabled={!selectedResource[inc.id]}
                                                    onClick={() => handleDispatch(inc.id)}
                                                    size="small"
                                                    title="اعزام"
                                                    sx={{ border: '1px solid', borderRadius: 1 }}
                                                 >
                                                     <Truck size={18} />
                                                 </IconButton>
                                                 
                                                 <Box borderLeft={1} borderColor="divider" height={24} mx={0.5} />
                                                 
                                                 <Button
                                                    variant="outlined"
                                                    color="success"
                                                    size="small"
                                                    startIcon={<Archive size={16} />}
                                                    onClick={() => handleOpenArchive(inc.id)}
                                                    sx={{ fontFamily: 'Vazirmatn', whiteSpace: 'nowrap' }}
                                                 >
                                                     پایان عملیات
                                                 </Button>
                                             </Box>
                                         </TableCell>
                                     </TableRow>
                                 );
                             })
                         )}
                     </TableBody>
                 </Table>
             </TableContainer>
        </Paper>

        {/* Vulnerability Map Section */}
        <Typography variant="h5" fontWeight="bold" fontFamily="Vazirmatn" mb={3} mt={6} color="text.primary">
            تحلیل نقاط آسیب‌پذیر (Vulnerability Hotspots)
        </Typography>
        
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="body1" color="text.secondary" fontFamily="Vazirmatn" sx={{ maxWidth: '70%' }}>
                نقشه زیر نقاطی که بر اساس گزارش‌های مردمی دارای "امتیاز ایمنی" پایین هستند را نشان می‌دهد. نقاط قرمز نشان‌دهنده ریسک بالا (بافت فرسوده، عدم رعایت ایمنی) هستند.
            </Typography>
            <FormControl size="small" sx={{ minWidth: 150, bgcolor: 'white' }}>
                <InputLabel sx={{ fontFamily: 'Vazirmatn' }}>فیلتر منطقه</InputLabel>
                <Select
                    value={vulnFilter}
                    label="فیلتر منطقه"
                    onChange={(e) => setVulnFilter(e.target.value)}
                    sx={{ fontFamily: 'Vazirmatn' }}
                >
                    <MenuItem value="all" sx={{ fontFamily: 'Vazirmatn' }}>همه مناطق</MenuItem>
                    {uniqueVulnRegions.map((r: any) => (
                        <MenuItem key={r} value={r} sx={{ fontFamily: 'Vazirmatn' }}>منطقه {toPersianDigits(r)}</MenuItem>
                    ))}
                </Select>
            </FormControl>
        </Box>

        <Paper sx={{ height: 500, width: '100%', borderRadius: 2, overflow: 'hidden', border: '1px solid #e2e8f0' }}>
            <MapContainer 
                center={[34.64, 50.87]} 
                zoom={13} 
                style={{ height: '100%', width: '100%' }}
            >
                <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                
                {filteredVulnPoints.map((point) => (
                    <CircleMarker 
                        key={point.id}
                        center={[point.lat, point.lng]}
                        radius={20}
                        pathOptions={{ 
                            color: 'white', 
                            fillColor: getRiskColor(point.score), 
                            fillOpacity: 0.7,
                            weight: 1
                        }}
                    >
                        <Popup>
                            <div style={{ fontFamily: 'Vazirmatn', textAlign: 'right', direction: 'rtl' }}>
                                <strong>منطقه آسیب‌پذیر</strong><br/>
                                امتیاز ایمنی: {toPersianDigits(point.score)} (از ۱۰۰)<br/>
                                منطقه شهرداری: {toPersianDigits(point.region)}
                            </div>
                        </Popup>
                    </CircleMarker>
                ))}
            </MapContainer>
        </Paper>

        <Box mt={2} display="flex" gap={2}>
             <Box display="flex" alignItems="center" gap={1}>
                 <Box width={16} height={16} bgcolor="#ef4444" borderRadius="50%" />
                 <Typography variant="body2" fontFamily="Vazirmatn">ریسک بالا (نیاز به توجه فوری)</Typography>
             </Box>
             <Box display="flex" alignItems="center" gap={1}>
                 <Box width={16} height={16} bgcolor="#f97316" borderRadius="50%" />
                 <Typography variant="body2" fontFamily="Vazirmatn">ریسک متوسط</Typography>
             </Box>
             <Box display="flex" alignItems="center" gap={1}>
                 <Box width={16} height={16} bgcolor="#eab308" borderRadius="50%" />
                 <Typography variant="body2" fontFamily="Vazirmatn">ریسک کم</Typography>
             </Box>
        </Box>
        
        <Snackbar open={snackbar.open} autoHideDuration={6000} onClose={() => setSnackbar({ ...snackbar, open: false })}>
            <Alert onClose={() => setSnackbar({ ...snackbar, open: false })} severity={snackbar.severity} sx={{ width: '100%', fontFamily: 'Vazirmatn' }}>
                {snackbar.message}
            </Alert>
        </Snackbar>

        {/* Archive Dialog */}
        <Dialog open={archiveOpen} onClose={() => setArchiveOpen(false)} fullWidth maxWidth="sm" dir="rtl">
            <DialogTitle sx={{ fontFamily: 'Vazirmatn', display: 'flex', alignItems: 'center', gap: 1 }}>
                <Archive className="text-blue-600" />
                پایان عملیات و بایگانی
            </DialogTitle>
            <DialogContent>
                <Typography variant="body2" color="text.secondary" fontFamily="Vazirmatn" mb={2}>
                    با تایید این عملیات، تمامی منابع تخصیص یافته آزاد شده و وضعیت حادثه به "حل شده" تغییر می‌یابد.
                </Typography>
                <TextField
                    label="گزارش نهایی عملیات"
                    multiline
                    rows={4}
                    fullWidth
                    value={closingReport}
                    onChange={(e) => setClosingReport(e.target.value)}
                    placeholder="شرح اقدامات انجام شده..."
                    sx={{ '& .MuiInputBase-root': { fontFamily: 'Vazirmatn' }, '& .MuiInputLabel-root': { fontFamily: 'Vazirmatn' } }}
                />
            </DialogContent>
            <DialogActions sx={{ p: 2 }}>
                <Button onClick={() => setArchiveOpen(false)} sx={{ fontFamily: 'Vazirmatn' }}>انصراف</Button>
                <Button 
                    variant="contained" 
                    color="primary" 
                    onClick={handleConfirmArchive} 
                    startIcon={<CheckCircle />}
                    sx={{ fontFamily: 'Vazirmatn' }}
                >
                    تایید و بایگانی
                </Button>
            </DialogActions>
        </Dialog>

    </Box>
  );
};

export default AnalyticsDashboard;
