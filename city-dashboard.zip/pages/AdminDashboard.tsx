
import React, { useState } from 'react';
import {
  Box,
  Grid,
  Typography,
  Paper,
  Tabs,
  Tab,
  useTheme,
  useMediaQuery,
  Avatar,
  IconButton
} from '@mui/material';
import {
  GppGoodOutlined,
  WarningAmberOutlined,
  HomeWorkOutlined,
  Dashboard as DashboardIcon,
  LocalShipping,
  BarChart,
  TrafficOutlined,
  Settings,
  Notifications
} from '@mui/icons-material';
import { MapContainer, TileLayer, CircleMarker, Tooltip } from 'react-leaflet';
import StatCard from '../components/StatCard';
import IncidentsTable from '../components/IncidentsTable';
import AlertForm from '../components/AlertForm';
import SupportMonitor from '../components/SupportMonitor';
import ResourceManager from '../components/ResourceManager';
import AnalyticsDashboard from './AnalyticsDashboard';
import TrafficMonitor from '../components/TrafficMonitor';

export interface Incident {
  id: string | number;
  title: string;
  type: string;
  status: string;
  lat?: string | number;
  lng?: string | number;
  severity?: string;
}

export interface DashboardStats {
  totalIncidents: number;
  safeCitizens: number;
  openShelters: number;
}

interface AdminDashboardProps {
  stats?: DashboardStats;
  incidents?: Incident[];
  onDataChange?: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  stats = { totalIncidents: 0, safeCitizens: 0, openShelters: 0 }, 
  incidents = [],
  onDataChange
}) => {
  const [currentTab, setCurrentTab] = useState(0);
  const theme = useTheme();
  
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setCurrentTab(newValue);
  };

  const getSeverityColor = (severity?: string) => {
    switch(severity) {
      case 'زیاد': return '#ef4444'; // Red
      case 'متوسط': return '#f97316'; // Orange
      case 'کم': return '#eab308'; // Yellow
      default: return '#ef4444';
    }
  };

  const renderOverview = () => (
    <>
      {/* Stats Grid */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <StatCard
            title="حوادث فعال"
            value={stats.totalIncidents}
            icon={<WarningAmberOutlined />}
            iconBgColor="bg-red-500"
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <StatCard
            title="شهروندان امن"
            value={stats.safeCitizens.toLocaleString()}
            icon={<GppGoodOutlined />}
            iconBgColor="bg-green-500"
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <StatCard
            title="پناهگاه‌های باز"
            value={stats.openShelters}
            icon={<HomeWorkOutlined />}
            iconBgColor="bg-blue-500"
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
           {/* Placeholder for 4th card or summary */}
           <StatCard
            title="نیروهای امدادی"
            value="۱۲"
            icon={<LocalShipping />}
            iconBgColor="bg-orange-500"
          />
        </Grid>
      </Grid>

      {/* Main Operations Area - Stretched Layout */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {/* Support & Chat Center - Full Width */}
        <Grid size={{ xs: 12 }}>
             <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Typography variant="h6" fontWeight="bold" fontFamily="Vazirmatn">مرکز پشتیبانی و چت اضطراری</Typography>
             </Box>
             <SupportMonitor />
        </Grid>

        {/* Live Map & Alert - Side by Side (Stretched horizontally) */}
        <Grid size={{ xs: 12, lg: 9 }}>
            <Paper 
                elevation={0} 
                sx={{ 
                    p: 0, 
                    borderRadius: 3, 
                    overflow: 'hidden', 
                    height: 350, // Reduced height for widescreen effect
                    border: '1px solid #e2e8f0', 
                    position: 'relative' 
                }}
            >
                <Box position="absolute" top={16} right={16} zIndex={400} bgcolor="white" p={1} borderRadius={2} boxShadow={1}>
                    <Typography variant="subtitle2" fontWeight="bold" fontFamily="Vazirmatn">نقشه زنده عملیات</Typography>
                </Box>
                <MapContainer 
                    center={[34.64, 50.87]} 
                    zoom={12} 
                    style={{ height: '100%', width: '100%' }}
                    zoomControl={false}
                >
                    <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                    {incidents.map((incident) => {
                    const lat = Number(incident.lat);
                    const lng = Number(incident.lng);
                    if (isNaN(lat) || isNaN(lng)) return null;
                    return (
                        <CircleMarker 
                        key={incident.id}
                        center={[lat, lng]}
                        radius={8}
                        pathOptions={{ color: 'white', fillColor: getSeverityColor(incident.severity), fillOpacity: 0.9, weight: 2 }}
                        />
                    );
                    })}
                </MapContainer>
            </Paper>
        </Grid>

        <Grid size={{ xs: 12, lg: 3 }}>
             <Box height={350}> {/* Match map height */}
                <AlertForm />
             </Box>
        </Grid>
      </Grid>
      
      {/* Incidents Table Section */}
      <Box mb={4}>
        <IncidentsTable onDataChange={onDataChange} />
      </Box>
    </>
  );

  return (
    <Box className="bg-gray-50 min-h-screen" dir="rtl" sx={{ p: { xs: 1, md: 3 } }}>
      {/* Header Section */}
      <Box mb={4} display="flex" flexDirection={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems="center" gap={2}>
        <Box>
            <Typography
                variant="h4"
                component="h1"
                fontWeight="bold"
                sx={{ fontFamily: 'Vazirmatn, sans-serif', color: '#0f172a', fontSize: { xs: '1.75rem', md: '2.25rem' }, mb: 0.5 }}
            >
            داشبورد مدیریت بحران
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ fontFamily: 'Vazirmatn, sans-serif', fontSize: '1rem', fontWeight: 500 }}>
            مرکز فرماندهی و عملیات
            </Typography>
        </Box>
        
        <Box display="flex" gap={1}>
            <IconButton sx={{ bgcolor: 'white', border: '1px solid #e2e8f0' }}><Notifications /></IconButton>
            <IconButton sx={{ bgcolor: 'white', border: '1px solid #e2e8f0' }}><Settings /></IconButton>
            <Avatar sx={{ bgcolor: '#3b82f6', ml: 1 }}>A</Avatar>
        </Box>
      </Box>

      {/* Tabs */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 4 }}>
          <Tabs 
            value={currentTab} 
            onChange={handleTabChange} 
            variant="scrollable"
            scrollButtons="auto"
            sx={{ 
                '& .MuiTab-root': { 
                    fontFamily: 'Vazirmatn', 
                    fontWeight: 'bold',
                    fontSize: '1rem',
                    minHeight: 56,
                    px: 3
                },
                '& .Mui-selected': {
                    color: '#3b82f6 !important',
                },
                '& .MuiTabs-indicator': {
                    backgroundColor: '#3b82f6',
                    height: 3,
                    borderRadius: '3px 3px 0 0'
                }
            }}
          >
              <Tab icon={<DashboardIcon sx={{ mb: 0, mr: 1 }} />} iconPosition="start" label="عملیات" />
              <Tab icon={<LocalShipping sx={{ mb: 0, mr: 1 }} />} iconPosition="start" label="مدیریت منابع" />
              <Tab icon={<BarChart sx={{ mb: 0, mr: 1 }} />} iconPosition="start" label="تحلیل و آمار" />
              <Tab icon={<TrafficOutlined sx={{ mb: 0, mr: 1 }} />} iconPosition="start" label="مدیریت ترافیک" />
          </Tabs>
      </Box>

      <Box>
          {currentTab === 0 && renderOverview()}
          {currentTab === 1 && <ResourceManager />}
          {currentTab === 2 && <AnalyticsDashboard />}
          {currentTab === 3 && <TrafficMonitor />}
      </Box>
    </Box>
  );
};

export default AdminDashboard;
